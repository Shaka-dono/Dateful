package com.dateful.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(private val onClick: (Item) -> Unit) : RecyclerView.Adapter<ItemAdapter.VH>() {

    private var data: List<Item> = emptyList()

    fun submit(list: List<Item>) {
        data = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val root: View = v.findViewById(R.id.rowRoot)
        val emoji: TextView = v.findViewById(R.id.tvEmoji)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val days: TextView = v.findViewById(R.id.tvDays)
        val divider: View = v.findViewById(R.id.divider)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = h.itemView.context
        val item = data[position]
        val n = data.size

        // le righe formano un unico gruppo arrotondato, come nelle liste di iOS
        h.root.setBackgroundResource(
            when {
                n == 1 -> R.drawable.bg_row_single
                position == 0 -> R.drawable.bg_row_top
                position == n - 1 -> R.drawable.bg_row_bottom
                else -> R.drawable.bg_row_mid
            }
        )
        h.divider.visibility = if (position == n - 1) View.GONE else View.VISIBLE

        when (item.type) {
            T_ABB -> Brands.show(h.emoji, item.name)
            T_SCAD -> {
                val i = item.category.coerceIn(0, SCAD_EMOJI.size - 1)
                Brands.emojiTile(h.emoji, SCAD_EMOJI[i], SCAD_COLORS[i])
            }
            else -> Brands.emojiTile(h.emoji, "🧾", 0xFF64748B.toInt())
        }
        h.title.text = item.name

        val parts = mutableListOf<String>()
        when (item.type) {
            T_GAR -> {
                if (item.store.isNotBlank()) parts.add(item.store)
                parts.add(c.getString(R.string.row_expires, fmtDate(item.date)))
            }
            T_ABB -> {
                if (item.cost > 0) parts.add(fmtMoney(c, item.cost))
                parts.add(repeatLabel(c, item.repeatMonths).lowercase())
                parts.add(c.getString(R.string.row_renews, fmtDate(item.date)))
            }
            else -> {
                parts.add(fmtDate(item.date))
                if (item.cost > 0) parts.add(fmtMoney(c, item.cost))
                if (item.repeatMonths > 0) parts.add(repeatLabel(c, item.repeatMonths).lowercase())
            }
        }
        h.sub.text = parts.joinToString(" · ")

        // stato come pillola dai colori tenui
        val d = item.daysLeft()
        val color = when {
            d <= 7 -> Color.parseColor("#DC2626")
            d <= 30 -> Color.parseColor("#D97706")
            else -> Color.parseColor("#16A34A")
        }
        val pill = GradientDrawable()
        pill.shape = GradientDrawable.RECTANGLE
        pill.cornerRadius = 40f * c.resources.displayMetrics.density
        pill.setColor(ColorUtils.setAlphaComponent(color, 36))
        h.days.background = pill
        h.days.setTextColor(color)
        h.days.text = daysText(c, d)

        h.root.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            onClick(item)
        }
    }
}
