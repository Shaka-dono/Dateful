package com.dateful.app

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.color.DynamicColors

object Appearance {

    fun themeKey(c: Context): String = Prefs.theme(c) + "|" + Prefs.accent(c)

    fun apply(a: Activity) {
        AppCompatDelegate.setDefaultNightMode(
            when (Prefs.theme(a)) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
        val accent = Prefs.accent(a)
        if (accent == "dynamic") {
            a.setTheme(R.style.Theme_Dateful_Teal)
            DynamicColors.applyToActivityIfAvailable(a)
        } else {
            a.setTheme(
                when (accent) {
                    "blue" -> R.style.Theme_Dateful_Blue
                    "indigo" -> R.style.Theme_Dateful_Indigo
                    "purple" -> R.style.Theme_Dateful_Purple
                    "pink" -> R.style.Theme_Dateful_Pink
                    "red" -> R.style.Theme_Dateful_Red
                    "orange" -> R.style.Theme_Dateful_Orange
                    "green" -> R.style.Theme_Dateful_Green
                    else -> R.style.Theme_Dateful_Teal
                }
            )
        }
    }
}
