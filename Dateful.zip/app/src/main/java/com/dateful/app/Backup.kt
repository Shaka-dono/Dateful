package com.dateful.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Backup {

    fun exportZip(c: Context, out: OutputStream) {
        ZipOutputStream(out).use { z ->
            val arr = JSONArray()
            for (i in Repo.all(c)) arr.put(i.toJson())
            val root = JSONObject().put("app", "dateful").put("version", 1).put("items", arr)
            z.putNextEntry(ZipEntry("items.json"))
            z.write(root.toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
            val dir = File(c.filesDir, "receipts")
            val files = dir.listFiles()
            if (files != null) {
                for (f in files) {
                    if (f.isFile && f.length() > 0) {
                        z.putNextEntry(ZipEntry("receipts/" + f.name))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
            }
        }
    }

    /** Unisce i dati del file a quelli presenti (stesso id = sostituisce). Restituisce quante voci ha letto. */
    fun importZip(c: Context, input: InputStream): Int {
        var json: String? = null
        val photos = HashMap<String, ByteArray>()
        val nameOk = Regex("^[A-Za-z0-9-]{1,64}\\.jpg$")
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val base = File(e.name).name
                    if (e.name == "items.json") {
                        json = z.readBytes().toString(Charsets.UTF_8)
                    } else if (e.name.startsWith("receipts/") && nameOk.matches(base)) {
                        photos[base] = z.readBytes()
                    }
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        val text = json ?: throw Exception("File non valido")
        val arr = JSONObject(text).getJSONArray("items")
        val list = Repo.all(c)
        var n = 0
        for (i in 0 until arr.length()) {
            val item = Item.fromJson(arr.getJSONObject(i))
            item.eventId = -1L
            item.notified = NOT_YET
            list.removeAll { it.id == item.id }
            list.add(item)
            n++
        }
        val dir = File(c.filesDir, "receipts")
        dir.mkdirs()
        for ((name, bytes) in photos) File(dir, name).writeBytes(bytes)
        Repo.save(c)
        return n
    }

    private fun q(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

    fun exportCsv(c: Context, out: OutputStream) {
        val sb = StringBuilder("\uFEFF")
        sb.append(c.getString(R.string.csv_header)).append("\n")
        for (i in Repo.all(c).sortedWith(compareBy({ it.type }, { it.date }))) {
            val tipo = when (i.type) {
                T_SCAD -> c.getString(R.string.type_deadline)
                T_ABB -> c.getString(R.string.type_subscription)
                else -> c.getString(R.string.type_warranty)
            }
            val cat = if (i.type == T_SCAD) scadName(c, i.category) else ""
            val cost = if (i.cost > 0) String.format(Locale.getDefault(), "%.2f", i.cost) else ""
            val rep = if (i.repeatMonths > 0) repeatLabel(c, i.repeatMonths) else ""
            val acq = i.purchase?.toString() ?: ""
            val mesi = if (i.type == T_GAR) i.months.toString() else ""
            sb.append(listOf(tipo, q(i.name), cat, i.date.toString(), cost, rep, q(i.store), acq, mesi).joinToString(";"))
            sb.append("\n")
        }
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
        out.flush()
    }

    fun wipe(c: Context) {
        Repo.all(c).clear()
        File(c.filesDir, "receipts").deleteRecursively()
        Repo.save(c)
    }
}
