package com.dateful.app

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

object Prefs {
    fun sp(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    fun theme(c: Context): String = sp(c).getString("theme", "system") ?: "system"
    fun accent(c: Context): String = sp(c).getString("accent", "teal") ?: "teal"

    fun notifEnabled(c: Context): Boolean = sp(c).getBoolean("notif_enabled", true)
    fun notifHour(c: Context): Int = (sp(c).getString("notif_hour", "9") ?: "9").toIntOrNull() ?: 9

    fun days(c: Context, subscription: Boolean): List<Int> {
        val key = if (subscription) "notif_days_sub" else "notif_days"
        val def = if (subscription) setOf("3", "0") else setOf("30", "7", "1", "0")
        val set: Set<String> = sp(c).getStringSet(key, def) ?: def
        return set.mapNotNull { it.toIntOrNull() }.sorted()
    }

    fun calEnabled(c: Context): Boolean = sp(c).getBoolean("cal_enabled", false)
    fun calTypes(c: Context): Set<Int> {
        val def = setOf("0", "1", "2")
        val set: Set<String> = sp(c).getStringSet("cal_types", def) ?: def
        return set.mapNotNull { it.toIntOrNull() }.toSet()
    }
    fun calId(c: Context): Long = (sp(c).getString("cal_id", "") ?: "").toLongOrNull() ?: -1L

    fun lock(c: Context): Boolean = sp(c).getBoolean("app_lock", false)
    fun sort(c: Context): String = sp(c).getString("sort", "date") ?: "date"
    fun icons(c: Context): Boolean = sp(c).getBoolean("icons_from_apps", true)
}
