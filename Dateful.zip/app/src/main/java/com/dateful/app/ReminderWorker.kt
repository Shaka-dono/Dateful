package com.dateful.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "scadenze"

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Promemoria scadenze", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun send(c: Context, item: Item, d: Long) {
        ensureChannel(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val title = when (item.type) {
            T_ABB -> "Rinnovo: " + item.name
            T_GAR -> "Garanzia: " + item.name
            else -> "Scadenza: " + item.name
        }
        val verb = if (item.type == T_ABB) "Si rinnova" else "Scade"
        val whenText = when {
            d < 0 -> "Scaduta da " + (-d) + " giorni"
            d == 0L -> "$verb oggi"
            d == 1L -> "$verb domani"
            else -> "$verb tra $d giorni"
        }
        var text = whenText + " (" + fmtDate(item.date) + ")"
        if (item.type == T_ABB && item.cost > 0) text += " · " + fmtMoney(item.cost)

        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(item.id.hashCode(), n)
        } catch (e: SecurityException) {
            // permesso notifiche negato
        }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Repo.rollSubscriptions(c)) CalendarSync.syncAll(c)
        if (!Prefs.notifEnabled(c)) return Result.success()
        var changed = false
        for (item in Repo.all(c).toList()) {
            val thresholds = Prefs.days(c, item.type == T_ABB)
            val d = item.daysLeft()
            val stage = thresholds.filter { d <= it }.minOrNull() ?: continue
            if (stage < item.notified) {
                Notifier.send(c, item, d)
                item.notified = stage
                changed = true
            }
        }
        if (changed) Repo.save(c)
        return Result.success()
    }
}

object Reminders {
    fun schedule(c: Context) {
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(Prefs.notifHour(c), 0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(c)
            .enqueueUniquePeriodicWork("reminders", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
