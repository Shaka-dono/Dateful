package com.dateful.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

object Notifier {
    const val CHANNEL = "scadenze"

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Promemoria scadenze", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun send(c: Context, item: Item, d: Long) {
        ensureChannel(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val title = when (item.type) {
            T_ABB -> "Rinnovo: " + item.name
            T_GAR -> "Garanzia: " + item.name
            else -> "Scadenza: " + item.name
        }
        val verb = if (item.type == T_ABB) "Si rinnova" else "Scade"
        val whenText = when {
            d < 0 -> "Scaduta da " + (-d) + " giorni"
            d == 0L -> "$verb oggi"
            d == 1L -> "$verb domani"
            else -> "$verb tra $d giorni"
        }
        var text = whenText + " (" + fmtDate(item.date) + ")"
        if (item.type == T_ABB && item.cost > 0) text += " · " + fmtMoney(item.cost)

        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(item.id.hashCode(), n)
        } catch (e: SecurityException) {
            // permesso notifiche negato
        }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        Repo.rollSubscriptions(c)
        var changed = false
        for (item in Repo.all(c)) {
            val thresholds = if (item.type == T_ABB) intArrayOf(3, 0) else intArrayOf(30, 7, 1, 0)
            val d = item.daysLeft()
            val stage = thresholds.filter { d <= it }.minOrNull() ?: continue
            if (stage < item.notified) {
                Notifier.send(c, item, d)
                item.notified = stage
                changed = true
            }
        }
        if (changed) Repo.save(c)
        return Result.success()
    }
}
