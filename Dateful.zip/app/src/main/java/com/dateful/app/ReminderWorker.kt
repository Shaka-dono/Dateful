package com.dateful.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "scadenze"

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, c.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun send(c: Context, item: Item, d: Long) {
        ensureChannel(c)
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val title = when (item.type) {
            T_ABB -> c.getString(R.string.notif_title_renewal, item.name)
            T_GAR -> c.getString(R.string.notif_title_warranty, item.name)
            else -> c.getString(R.string.notif_title_deadline, item.name)
        }
        val sub = item.type == T_ABB
        val whenText = when {
            d < 0 -> c.getString(R.string.notif_overdue, -d)
            d == 0L -> c.getString(if (sub) R.string.notif_renews_today else R.string.notif_due_today)
            d == 1L -> c.getString(if (sub) R.string.notif_renews_tomorrow else R.string.notif_due_tomorrow)
            else -> c.getString(if (sub) R.string.notif_renews_in else R.string.notif_due_in, d)
        }
        var text = whenText + " (" + fmtDate(item.date) + ")"
        if (sub && item.cost > 0) text += " · " + fmtMoney(c, item.cost)

        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(item.id.hashCode(), n)
        } catch (e: SecurityException) {
            // permesso notifiche negato
        }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Repo.rollSubscriptions(c)) CalendarSync.syncAll(c)
        if (!Prefs.notifEnabled(c)) return Result.success()
        var changed = false
        for (item in Repo.all(c).toList()) {
            val thresholds = Prefs.days(c, item.type == T_ABB)
            val d = item.daysLeft()
            val stage = thresholds.filter { d <= it }.minOrNull() ?: continue
            if (stage < item.notified) {
                Notifier.send(c, item, d)
                item.notified = stage
                changed = true
            }
        }
        if (changed) Repo.save(c)
        return Result.success()
    }
}

object Reminders {
    fun schedule(c: Context) {
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(Prefs.notifHour(c), 0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(c)
            .enqueueUniquePeriodicWork("reminders", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
