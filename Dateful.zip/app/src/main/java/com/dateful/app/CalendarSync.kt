package com.dateful.app

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract.Calendars
import android.provider.CalendarContract.Events
import java.time.ZoneOffset

/** Crea e aggiorna gli eventi nel calendario del telefono, senza creare doppioni. */
object CalendarSync {

    private const val MARK = "[dateful:"

    fun granted(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Calendari su cui si puo' scrivere: coppie (id, nome). */
    fun calendars(c: Context): List<Pair<Long, String>> {
        val out = mutableListOf<Pair<Long, String>>()
        if (!granted(c)) return out
        val proj = arrayOf(Calendars._ID, Calendars.CALENDAR_DISPLAY_NAME, Calendars.ACCOUNT_NAME)
        try {
            c.contentResolver.query(
                Calendars.CONTENT_URI, proj,
                Calendars.CALENDAR_ACCESS_LEVEL + " >= ? AND " + Calendars.VISIBLE + " = 1",
                arrayOf(Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
                Calendars.CALENDAR_DISPLAY_NAME
            )?.use { cur ->
                while (cur.moveToNext()) {
                    out.add(cur.getLong(0) to (cur.getString(1) + " (" + cur.getString(2) + ")"))
                }
            }
        } catch (e: Exception) {
            // calendario non leggibile
        }
        return out
    }

    private fun title(c: Context, i: Item): String = when (i.type) {
        T_ABB -> c.getString(R.string.cal_title_renewal, i.name)
        T_GAR -> c.getString(R.string.cal_title_warranty, i.name)
        else -> c.getString(R.string.cal_title_deadline, i.name)
    }

    private fun description(c: Context, i: Item): String {
        val sb = StringBuilder()
        if (i.cost > 0) sb.append(c.getString(R.string.cal_amount, fmtMoney(c, i.cost))).append("\n")
        if (i.type == T_GAR && i.store.isNotBlank()) sb.append(c.getString(R.string.cal_store, i.store)).append("\n")
        sb.append(c.getString(R.string.cal_created_by)).append(" ").append(MARK).append(i.id).append("]")
        return sb.toString()
    }

    // Cerca un evento gia' creato da Dateful per questa voce (utile dopo reinstallazione e importazione).
    private fun find(c: Context, calId: Long, id: String): Long {
        c.contentResolver.query(
            Events.CONTENT_URI, arrayOf(Events._ID),
            Events.CALENDAR_ID + " = ? AND " + Events.DESCRIPTION + " LIKE ? AND " + Events.DELETED + " = 0",
            arrayOf(calId.toString(), "%" + MARK + id + "]%"), null
        )?.use { cur ->
            if (cur.moveToFirst()) return cur.getLong(0)
        }
        return -1L
    }

    private fun values(c: Context, item: Item): ContentValues {
        val start = item.date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val v = ContentValues()
        v.put(Events.DTSTART, start)
        v.put(Events.DTEND, start + 86_400_000L)
        v.put(Events.ALL_DAY, 1)
        v.put(Events.EVENT_TIMEZONE, "UTC")
        v.put(Events.TITLE, title(c, item))
        v.put(Events.DESCRIPTION, description(c, item))
        return v
    }

    // true se e' cambiato l'id dell'evento memorizzato
    private fun upsert(c: Context, item: Item, calId: Long): Boolean {
        val v = values(c, item)
        if (item.eventId >= 0) {
            val n = c.contentResolver.update(ContentUris.withAppendedId(Events.CONTENT_URI, item.eventId), v, null, null)
            if (n > 0) return false
            item.eventId = -1L
        }
        val existing = find(c, calId, item.id)
        if (existing >= 0) {
            c.contentResolver.update(ContentUris.withAppendedId(Events.CONTENT_URI, existing), v, null, null)
            item.eventId = existing
            return true
        }
        v.put(Events.CALENDAR_ID, calId)
        val uri = c.contentResolver.insert(Events.CONTENT_URI, v)
        item.eventId = uri?.lastPathSegment?.toLongOrNull() ?: -1L
        return item.eventId >= 0
    }

    fun deleteEvent(c: Context, eventId: Long) {
        if (eventId < 0 || !granted(c)) return
        try {
            c.contentResolver.delete(ContentUris.withAppendedId(Events.CONTENT_URI, eventId), null, null)
        } catch (e: Exception) {
            // evento gia' rimosso
        }
    }

    @Synchronized
    fun syncAll(c: Context) {
        if (!granted(c) || !Prefs.calEnabled(c)) return
        val calId = Prefs.calId(c)
        if (calId < 0) return
        val types = Prefs.calTypes(c)
        var changed = false
        try {
            for (item in Repo.all(c).toList()) {
                if (item.type in types) {
                    if (upsert(c, item, calId)) changed = true
                } else if (item.eventId >= 0) {
                    deleteEvent(c, item.eventId)
                    item.eventId = -1L
                    changed = true
                }
            }
        } catch (e: Exception) {
            // permesso revocato o calendario non disponibile
        }
        if (changed) Repo.save(c)
    }

    @Synchronized
    fun removeAll(c: Context) {
        for (item in Repo.all(c).toList()) {
            if (item.eventId >= 0) {
                deleteEvent(c, item.eventId)
                item.eventId = -1L
            }
        }
        Repo.save(c)
    }
}
