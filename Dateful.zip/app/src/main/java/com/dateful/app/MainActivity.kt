package com.dateful.app

import android.Manifest
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var tab = T_SCAD
    private lateinit var adapter: ItemAdapter
    private lateinit var tvTitle: TextView
    private lateinit var tvSummary: TextView
    private lateinit var tvEmpty: TextView
    private var photoButton: MaterialButton? = null

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoButton?.text = "✓ Foto salvata (tocca per rifarla)"
        }

    private val takeDocPhoto =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) importDocument(docPhotoUri())
        }

    private val pickDocument =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) importDocument(uri)
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var themeKeyAtStart = ""
    private var unlocked = false
    private var leftAt = 0L
    private var promptShowing = false
    private lateinit var lockOverlay: View

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        themeKeyAtStart = Appearance.themeKey(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTitle = findViewById(R.id.tvTitle)
        tvSummary = findViewById(R.id.tvSummary)
        tvEmpty = findViewById(R.id.tvEmpty)
        lockOverlay = findViewById(R.id.lockOverlay)
        findViewById<View>(R.id.btnUnlock).setOnClickListener { if (!promptShowing) promptUnlock() }
        findViewById<TextView>(R.id.tvSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val rv = findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ItemAdapter { onItemClick(it) }
        rv.adapter = adapter

        findViewById<BottomNavigationView>(R.id.nav).setOnItemSelectedListener { m ->
            tab = when (m.itemId) {
                R.id.nav_scad -> T_SCAD
                R.id.nav_abb -> T_ABB
                else -> T_GAR
            }
            refresh()
            true
        }
        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            when (tab) {
                T_SCAD -> showAddChooser()
                T_ABB -> showAbbChooser()
                else -> showForm(null)
            }
        }

        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        scheduleReminders()
    }

    override fun onResume() {
        super.onResume()
        if (Appearance.themeKey(this) != themeKeyAtStart) {
            recreate()
            return
        }
        AppIcons.reset()
        if (Repo.rollSubscriptions(this)) syncCalendar()
        checkLock()
        refresh()
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
    }

    private fun scheduleReminders() {
        Reminders.schedule(applicationContext)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun receiptFile(id: String): File {
        val dir = File(filesDir, "receipts")
        dir.mkdirs()
        return File(dir, "$id.jpg")
    }

    private fun receiptExists(id: String): Boolean {
        val f = receiptFile(id)
        return f.exists() && f.length() > 0
    }

    private fun refresh() {
        val filtered = Repo.all(this).filter { it.type == tab }
        val list = when (Prefs.sort(this)) {
            "name" -> filtered.sortedBy { it.name.lowercase() }
            "amount" -> filtered.sortedByDescending { it.cost }
            else -> filtered.sortedBy { it.date }
        }
        adapter.submit(list)

        tvTitle.text = when (tab) {
            T_SCAD -> "Scadenze"
            T_ABB -> "Abbonamenti"
            else -> "Garanzie"
        }
        tvEmpty.text = when (tab) {
            T_SCAD -> "Nessuna scadenza.\nToccando + aggiungi bollo, revisione, assicurazione, tagliando, caldaia..."
            T_ABB -> "Nessun abbonamento.\nToccando + aggiungi Netflix, palestra, telefono..."
            else -> "Nessuna garanzia.\nToccando + salvi un acquisto con la foto dello scontrino."
        }
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE

        val annual = list
            .filter { it.cost > 0 && it.repeatMonths > 0 }
            .sumOf { it.cost * 12.0 / it.repeatMonths }
        tvSummary.text = when (tab) {
            T_SCAD -> {
                var s = "${list.size} scadenze"
                if (annual > 0) s += "\nSpesa annua stimata: " + fmtMoney(annual)
                s
            }
            T_ABB -> "Al mese: " + fmtMoney(annual / 12.0) + "\nIn un anno: " + fmtMoney(annual)
            else -> {
                val active = list.count { it.daysLeft() >= 0 }
                val soon = list.count { val d = it.daysLeft(); d >= 0 && d <= 60 }
                "$active attive · $soon in scadenza entro 60 giorni"
            }
        }
        tvSummary.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun onItemClick(item: Item) {
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        actions.add("✏️ Modifica" to { showForm(item) })
        if (item.type == T_SCAD && item.repeatMonths > 0) {
            actions.add("✅ Rinnovata: sposta alla prossima" to { renew(item) })
        }
        if (item.type == T_GAR && receiptExists(item.id)) {
            actions.add("🧾 Vedi scontrino" to { viewReceipt(item) })
        }
        actions.add("🗑️ Elimina" to { confirmDelete(item) })

        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .show()
    }

    private fun renew(item: Item) {
        val today = LocalDate.now()
        item.date = item.date.plusMonths(item.repeatMonths.toLong())
        while (item.date.isBefore(today)) item.date = item.date.plusMonths(item.repeatMonths.toLong())
        item.notified = NOT_YET
        Repo.save(this)
        syncCalendar()
        refresh()
        Toast.makeText(this, "Prossima scadenza: " + fmtDate(item.date), Toast.LENGTH_LONG).show()
    }

    private fun viewReceipt(item: Item) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", receiptFile(item.id))
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "image/jpeg")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Impossibile aprire la foto", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDelete(item: Item) {
        AlertDialog.Builder(this)
            .setTitle("Eliminare?")
            .setMessage(item.name)
            .setPositiveButton("Elimina") { _, _ ->
                val ev = item.eventId
                Repo.all(this).remove(item)
                receiptFile(item.id).delete()
                Repo.save(this)
                refresh()
                if (ev >= 0) {
                    val app = applicationContext
                    thread { CalendarSync.deleteEvent(app, ev) }
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun docPhotoUri(): Uri {
        val dir = File(cacheDir, "scan")
        dir.mkdirs()
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "photo.jpg"))
    }

    private fun showAddChooser() {
        val labels = arrayOf(
            "✍️ Inserisci a mano",
            "📷 Scatta una foto del documento",
            "🖼️ Scegli una foto dalla galleria",
            "📄 Scegli un PDF"
        )
        AlertDialog.Builder(this)
            .setTitle("Nuova scadenza")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> showForm(null)
                    1 -> try {
                        takeDocPhoto.launch(docPhotoUri())
                    } catch (e: Exception) {
                        Toast.makeText(this, "Fotocamera non disponibile", Toast.LENGTH_LONG).show()
                    }
                    2 -> pickDocument.launch("image/*")
                    else -> pickDocument.launch("application/pdf")
                }
            }
            .show()
    }

    private fun importDocument(uri: Uri) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(24), dp(24), dp(24), dp(24))
        row.addView(ProgressBar(this))
        val msg = TextView(this)
        msg.text = "  Leggo il documento..."
        msg.textSize = 16f
        row.addView(msg)
        val dlg = AlertDialog.Builder(this).setView(row).setCancelable(false).create()
        dlg.show()

        thread {
            try {
                val text = DocReader.readText(applicationContext, uri)
                val scan = DocParser.parse(text)
                runOnUiThread {
                    dlg.dismiss()
                    if (text.isBlank()) {
                        AlertDialog.Builder(this)
                            .setTitle("Non riesco a leggerlo")
                            .setMessage("Non ho trovato testo. Prova con una foto più nitida, ben illuminata e che inquadri tutto il foglio.")
                            .setPositiveButton("Inserisci a mano") { _, _ -> showForm(null) }
                            .setNegativeButton("Annulla", null)
                            .show()
                    } else {
                        showForm(null, scan)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlg.dismiss()
                    AlertDialog.Builder(this)
                        .setTitle("Errore")
                        .setMessage("Non riesco ad aprire il file: " + (e.message ?: "errore sconosciuto"))
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
    }

    private fun syncCalendar() {
        val app = applicationContext
        thread { CalendarSync.syncAll(app) }
    }

    private fun checkLock() {
        val now = SystemClock.elapsedRealtime()
        if (Prefs.lock(this) && (!unlocked || now - leftAt > 120_000L)) {
            unlocked = false
            lockOverlay.visibility = View.VISIBLE
            if (!promptShowing) promptUnlock()
        } else {
            lockOverlay.visibility = View.GONE
        }
    }

    private fun promptUnlock() {
        promptShowing = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    unlocked = true
                    leftAt = SystemClock.elapsedRealtime()
                    lockOverlay.visibility = View.GONE
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    promptShowing = false
                    // se il telefono non ha piu' un blocco schermo, si disattiva il blocco per non chiudere fuori l'utente
                    if (errorCode == BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL ||
                        errorCode == BiometricPrompt.ERROR_NO_BIOMETRICS ||
                        errorCode == BiometricPrompt.ERROR_HW_NOT_PRESENT
                    ) {
                        Prefs.sp(this@MainActivity).edit().putBoolean("app_lock", false).apply()
                        unlocked = true
                        lockOverlay.visibility = View.GONE
                    }
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Sblocca Dateful")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }

    private fun showAbbChooser() {
        val labels = arrayOf("✍️ Inserisci a mano", "📲 Scegli da app installate")
        AlertDialog.Builder(this)
            .setTitle("Nuovo abbonamento")
            .setItems(labels) { _, which ->
                if (which == 0) showForm(null) else showAppPicker()
            }
            .show()
    }

    private fun showAppPicker() {
        val all = AppIcons.apps(this)
        if (all.isEmpty()) {
            Toast.makeText(this, "Non vedo app installate: inserisci a mano", Toast.LENGTH_LONG).show()
            showForm(null)
            return
        }
        val shown = all.toMutableList()
        val ctx = this

        val adapter = object : ArrayAdapter<AppIcons.AppInfo>(ctx, 0, shown) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row: LinearLayout
                if (convertView is LinearLayout) {
                    row = convertView
                } else {
                    row = LinearLayout(ctx)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.setPadding(dp(16), dp(8), dp(16), dp(8))
                    val iv = ImageView(ctx)
                    iv.id = 1001
                    row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                    val tv = TextView(ctx)
                    tv.id = 1002
                    tv.textSize = 16f
                    tv.setPadding(dp(16), 0, 0, 0)
                    row.addView(tv)
                }
                val info = shown[position]
                val icon = try {
                    ctx.packageManager.getApplicationIcon(info.pkg)
                } catch (e: Exception) {
                    null
                }
                row.findViewById<ImageView>(1001).setImageDrawable(icon)
                row.findViewById<TextView>(1002).text = info.label
                return row
            }
        }

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        val search = EditText(ctx)
        search.hint = "Cerca app"
        search.inputType = InputType.TYPE_CLASS_TEXT
        box.addView(search)
        val list = ListView(ctx)
        list.adapter = adapter
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim() ?: ""
                shown.clear()
                shown.addAll(all.filter { it.label.contains(q, ignoreCase = true) })
                adapter.notifyDataSetChanged()
            }
        })

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("Scegli l'app")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .create()
        list.setOnItemClickListener { _, _, pos, _ ->
            val chosen = shown[pos]
            dlg.dismiss()
            showForm(null, null, chosen.label)
        }
        dlg.show()
    }

    private fun outlined(label: String): MaterialButton {
        val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        b.text = label
        b.isAllCaps = false
        return b
    }

    private fun showForm(existing: Item?, prefill: Scan? = null, presetName: String? = null) {
        val type = existing?.type ?: tab
        val id = existing?.id ?: UUID.randomUUID().toString()
        val today = LocalDate.now()
        var date: LocalDate = if (existing == null) (prefill?.date ?: today)
        else if (type == T_GAR) (existing.purchase ?: today) else existing.date

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))

        if (prefill != null) {
            val info = TextView(this)
            val sb = StringBuilder("📄 Letto dal documento: controlla i dati prima di salvare.")
            if (prefill.date == null) sb.append("\nNon ho trovato una data: scegli tu la scadenza.")
            if (prefill.amount == null) sb.append("\nNon ho trovato un importo.")
            if (prefill.otherDates.isNotEmpty()) {
                sb.append("\nAltre date trovate: " + prefill.otherDates.joinToString(", ") { fmtDate(it) })
            }
            if (prefill.otherAmounts.isNotEmpty()) {
                sb.append("\nAltri importi: " + prefill.otherAmounts.joinToString(", ") { fmtMoney(it) })
            }
            info.text = sb.toString()
            info.textSize = 13f
            box.addView(info)
        }

        fun addLabel(t: String) {
            val tv = TextView(this@MainActivity)
            tv.text = t
            tv.textSize = 13f
            tv.setPadding(0, dp(14), 0, 0)
            box.addView(tv)
        }

        val repVals = if (type == T_ABB) REPEAT_VALUES.drop(1) else REPEAT_VALUES
        val repLabs = if (type == T_ABB) REPEAT_LABELS.drop(1) else REPEAT_LABELS
        val defaultRep = if (type == T_ABB) 1 else 0

        val spRep = Spinner(this)
        spRep.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, repLabs)
        val repIndex = repVals.indexOf(existing?.repeatMonths ?: defaultRep)
        spRep.setSelection(if (repIndex < 0) 0 else repIndex)

        val spCat = Spinner(this)
        spCat.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            SCAD_EMOJI.indices.map { SCAD_EMOJI[it] + " " + SCAD_NAMES[it] }
        )
        spCat.setSelection(existing?.category ?: prefill?.category ?: 0)
        spCat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, rowId: Long) {
                if (existing == null) {
                    val idx = repVals.indexOf(SCAD_DEFAULT_REPEAT[pos])
                    spRep.setSelection(if (idx < 0) 0 else idx)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val etName: EditText = if (type == T_ABB) {
            val ac = AutoCompleteTextView(this)
            ac.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Brands.suggestions))
            ac.threshold = 1
            ac
        } else {
            EditText(this)
        }
        etName.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        etName.setText(existing?.name ?: prefill?.name ?: presetName ?: "")
        etName.hint = when (type) {
            T_SCAD -> "es. Bollo Peugeot 206"
            T_ABB -> "es. Netflix"
            else -> "es. Lavatrice"
        }

        // abbonamenti: il badge cambia mentre scrivi il nome del servizio
        val preview = TextView(this)
        val nameRow = LinearLayout(this)
        if (type == T_ABB) {
            Brands.show(preview, etName.text.toString())
            etName.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    Brands.show(preview, s?.toString() ?: "")
                }
            })
            nameRow.orientation = LinearLayout.HORIZONTAL
            nameRow.gravity = Gravity.CENTER_VERTICAL
            nameRow.addView(preview)
            nameRow.addView(etName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        val etCost = EditText(this)
        etCost.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        etCost.hint = "0,00"
        val prefillAmount = prefill?.amount
        if (existing != null && existing.cost > 0) {
            etCost.setText(String.format(Locale.ITALY, "%.2f", existing.cost))
        } else if (existing == null && prefillAmount != null) {
            etCost.setText(String.format(Locale.ITALY, "%.2f", prefillAmount))
        }

        val etStore = EditText(this)
        etStore.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        etStore.hint = "es. MediaWorld"
        etStore.setText(existing?.store ?: "")

        val etMonths = EditText(this)
        etMonths.inputType = InputType.TYPE_CLASS_NUMBER
        etMonths.setText((existing?.months ?: 24).toString())

        val btnDate = outlined("📅  " + fmtDate(date))
        btnDate.setOnClickListener {
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    date = LocalDate.of(y, m + 1, d)
                    btnDate.text = "📅  " + fmtDate(date)
                },
                date.year, date.monthValue - 1, date.dayOfMonth
            ).show()
        }

        val btnPhoto = outlined(if (receiptExists(id)) "✓ Foto presente (tocca per rifarla)" else "📷  Foto dello scontrino")
        btnPhoto.setOnClickListener {
            photoButton = btnPhoto
            try {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", receiptFile(id))
                takePicture.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(this, "Fotocamera non disponibile", Toast.LENGTH_LONG).show()
            }
        }

        when (type) {
            T_SCAD -> {
                addLabel("Tipo"); box.addView(spCat)
                addLabel("Nome"); box.addView(etName)
                addLabel("Scadenza"); box.addView(btnDate)
                addLabel("Importo da pagare (€)"); box.addView(etCost)
                addLabel("Si ripete"); box.addView(spRep)
            }
            T_ABB -> {
                addLabel("Nome del servizio"); box.addView(nameRow)
                addLabel("Costo (€)"); box.addView(etCost)
                addLabel("Si rinnova"); box.addView(spRep)
                addLabel("Prossimo rinnovo"); box.addView(btnDate)
            }
            else -> {
                addLabel("Prodotto"); box.addView(etName)
                addLabel("Negozio"); box.addView(etStore)
                addLabel("Data di acquisto"); box.addView(btnDate)
                addLabel("Durata garanzia (mesi)"); box.addView(etMonths)
                addLabel("Scontrino"); box.addView(btnPhoto)
            }
        }

        val scroll = ScrollView(this)
        scroll.addView(box)

        val title = when (type) {
            T_SCAD -> if (existing == null) "Nuova scadenza" else "Modifica scadenza"
            T_ABB -> if (existing == null) "Nuovo abbonamento" else "Modifica abbonamento"
            else -> if (existing == null) "Nuova garanzia" else "Modifica garanzia"
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Salva", null)
            .setNegativeButton("Annulla", null)
            .create()
        dialog.show()

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val name = etName.text.toString().trim()
            val finalName = if (name.isEmpty() && type == T_SCAD) SCAD_NAMES[spCat.selectedItemPosition] else name
            if (finalName.isEmpty()) {
                Toast.makeText(this, "Scrivi un nome", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val cost = etCost.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
            val rep = repVals[spRep.selectedItemPosition]

            val item = existing ?: Item(id = id, type = type, name = finalName, date = date)
            val oldDate = existing?.date
            item.name = finalName
            when (type) {
                T_SCAD -> {
                    item.category = spCat.selectedItemPosition
                    item.date = date
                    item.cost = cost
                    item.repeatMonths = rep
                }
                T_ABB -> {
                    item.date = date
                    item.cost = cost
                    item.repeatMonths = rep
                }
                else -> {
                    val m = (etMonths.text.toString().toIntOrNull() ?: 24).coerceIn(1, 600)
                    item.store = etStore.text.toString().trim()
                    item.purchase = date
                    item.months = m
                    item.date = date.plusMonths(m.toLong())
                }
            }
            if (oldDate != null && oldDate != item.date) item.notified = NOT_YET
            if (existing == null) Repo.all(this).add(item)
            Repo.save(this)
            syncCalendar()
            refresh()
            dialog.dismiss()
        }
    }
}
