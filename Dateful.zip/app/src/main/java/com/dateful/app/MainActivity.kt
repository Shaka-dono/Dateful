package com.dateful.app

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File
import java.time.LocalDate
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private class SheetRow(val label: String, val destructive: Boolean, val action: () -> Unit)

    private class Choice(val tv: TextView, val labels: List<String>, var index: Int) {
        fun set(i: Int) {
            index = i
            tv.text = labels[i] + "   ›"
        }
    }

    private var tab = T_SCAD
    private lateinit var adapter: ItemAdapter
    private lateinit var rv: RecyclerView
    private lateinit var tvTitle: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var heroCard: View
    private lateinit var tvHeroLabel: TextView
    private lateinit var tvHeroBig: TextView
    private lateinit var tvHeroSub: TextView
    private lateinit var lockOverlay: View
    private var photoButton: MaterialButton? = null

    private var themeKeyAtStart = ""
    private var unlocked = false
    private var leftAt = 0L
    private var promptShowing = false

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoButton?.text = getString(R.string.photo_saved)
        }

    private val takeDocPhoto =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) importDocument(docPhotoUri())
        }

    private val pickDocument =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) importDocument(uri)
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        themeKeyAtStart = Appearance.themeKey(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTitle = findViewById(R.id.tvTitle)
        tvEmpty = findViewById(R.id.tvEmpty)
        heroCard = findViewById(R.id.heroCard)
        tvHeroLabel = findViewById(R.id.tvHeroLabel)
        tvHeroBig = findViewById(R.id.tvHeroBig)
        tvHeroSub = findViewById(R.id.tvHeroSub)
        lockOverlay = findViewById(R.id.lockOverlay)
        findViewById<TextView>(R.id.tvLockTitle).text = getString(R.string.lock_locked)
        val btnUnlock = findViewById<MaterialButton>(R.id.btnUnlock)
        btnUnlock.text = getString(R.string.lock_unlock)
        btnUnlock.setOnClickListener { if (!promptShowing) promptUnlock() }
        styleHero()

        rv = findViewById(R.id.list)
        rv.layoutManager = LinearLayoutManager(this)
        rv.layoutAnimation = AnimationUtils.loadLayoutAnimation(this, R.anim.layout_in)
        adapter = ItemAdapter { onItemClick(it) }
        rv.adapter = adapter

        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener { m ->
            nav.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            tab = when (m.itemId) {
                R.id.nav_scad -> T_SCAD
                R.id.nav_abb -> T_ABB
                else -> T_GAR
            }
            refresh(true)
            true
        }
        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            showAddSheet()
        }
        findViewById<TextView>(R.id.tvSettings).setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Reminders.schedule(applicationContext)
    }

    override fun onResume() {
        super.onResume()
        if (Appearance.themeKey(this) != themeKeyAtStart) {
            recreate()
            return
        }
        AppIcons.reset()
        if (Repo.rollSubscriptions(this)) syncCalendar()
        checkLock()
        refresh(false)
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
    }

    // ---------- piccoli aiuti grafici ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun onSurface(): Int =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, Color.BLACK)

    private fun onSurfaceVariant(): Int =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

    private fun styleHero() {
        val primary = MaterialColors.getColor(heroCard, com.google.android.material.R.attr.colorPrimary)
        val onPrimary = MaterialColors.getColor(heroCard, com.google.android.material.R.attr.colorOnPrimary)
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(primary, ColorUtils.blendARGB(primary, Color.BLACK, 0.30f))
        )
        g.cornerRadius = dp(28).toFloat()
        heroCard.background = g
        tvHeroLabel.setTextColor(ColorUtils.setAlphaComponent(onPrimary, 215))
        tvHeroBig.setTextColor(onPrimary)
        tvHeroSub.setTextColor(ColorUtils.setAlphaComponent(onPrimary, 215))
    }

    private fun fieldBg(): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(14).toFloat()
        g.setColor(
            MaterialColors.getColor(
                this, com.google.android.material.R.attr.colorSurfaceVariant, 0xFFEEEEF3.toInt()
            )
        )
        return g
    }

    private fun styleField(v: TextView) {
        v.background = fieldBg()
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.textSize = 17f
        v.setTextColor(onSurface())
    }

    private fun choiceField(
        labels: List<String>, start: Int, title: String, onPick: (Int) -> Unit = {}
    ): Choice {
        val tv = TextView(this)
        styleField(tv)
        val ch = Choice(tv, labels, 0)
        ch.set(start.coerceIn(0, labels.size - 1))
        tv.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(labels.toTypedArray(), ch.index) { dlg, which ->
                    ch.set(which)
                    onPick(which)
                    dlg.dismiss()
                }
                .show()
        }
        return ch
    }

    private fun outlined(label: String): MaterialButton {
        val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        b.text = label
        b.isAllCaps = false
        b.cornerRadius = dp(28)
        return b
    }

    private fun sheetList(title: String, rows: List<SheetRow>) {
        val d = BottomSheetDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(14), dp(8), dp(24))
        val t = TextView(this)
        t.text = title
        t.textSize = 22f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(onSurface())
        t.setPadding(dp(20), dp(8), dp(20), dp(12))
        box.addView(t)
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for (r in rows) {
            val row = TextView(this)
            row.text = r.label
            row.textSize = 17f
            row.setPadding(dp(20), dp(16), dp(20), dp(16))
            row.setTextColor(if (r.destructive) Color.parseColor("#DC2626") else onSurface())
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener {
                d.dismiss()
                r.action()
            }
            box.addView(row)
        }
        d.setContentView(box)
        d.show()
    }

    // ---------- elenco e riepilogo ----------

    private fun annualCost(list: List<Item>): Double =
        list.filter { it.cost > 0 && it.repeatMonths > 0 }.sumOf { it.cost * 12.0 / it.repeatMonths }

    private fun refresh(animate: Boolean) {
        val filtered = Repo.all(this).filter { it.type == tab }
        val list = when (Prefs.sort(this)) {
            "name" -> filtered.sortedBy { it.name.lowercase() }
            "amount" -> filtered.sortedByDescending { it.cost }
            else -> filtered.sortedBy { it.date }
        }
        adapter.submit(list)
        if (animate) rv.scheduleLayoutAnimation()

        tvTitle.text = getString(
            when (tab) {
                T_SCAD -> R.string.tab_deadlines
                T_ABB -> R.string.tab_subs
                else -> R.string.tab_warranties
            }
        )
        tvEmpty.text = getString(
            when (tab) {
                T_SCAD -> R.string.empty_deadlines
                T_ABB -> R.string.empty_subs
                else -> R.string.empty_warranties
            }
        )
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        heroCard.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        updateHero(filtered)
    }

    private fun updateHero(list: List<Item>) {
        when (tab) {
            T_SCAD -> {
                tvHeroLabel.text = getString(R.string.hero_next_deadline)
                val next = list.filter { it.daysLeft() >= 0 }.minByOrNull { it.date }
                    ?: list.minByOrNull { it.date }
                if (next == null) {
                    tvHeroBig.text = getString(R.string.hero_none)
                    tvHeroSub.text = ""
                } else {
                    tvHeroBig.text = daysText(this, next.daysLeft()).replaceFirstChar { it.uppercase() }
                    val annual = annualCost(list)
                    tvHeroSub.text = if (annual > 0) {
                        next.name + " · " + getString(R.string.hero_year_spend, fmtMoney(this, annual))
                    } else {
                        next.name
                    }
                }
            }
            T_ABB -> {
                val annual = annualCost(list)
                tvHeroLabel.text = getString(R.string.hero_monthly)
                tvHeroBig.text = getString(R.string.hero_per_month, fmtMoney(this, annual / 12.0))
                tvHeroSub.text = getString(R.string.hero_year_count, fmtMoney(this, annual), list.size)
            }
            else -> {
                val active = list.count { it.daysLeft() >= 0 }
                val soon = list.count { val d = it.daysLeft(); d >= 0 && d <= 60 }
                tvHeroLabel.text = getString(R.string.hero_warranties)
                tvHeroBig.text = getString(R.string.hero_active, active)
                tvHeroSub.text = getString(R.string.hero_expiring, soon)
            }
        }
    }

    // ---------- azioni su una voce ----------

    private fun receiptFile(id: String): File {
        val dir = File(filesDir, "receipts")
        dir.mkdirs()
        return File(dir, "$id.jpg")
    }

    private fun receiptExists(id: String): Boolean {
        val f = receiptFile(id)
        return f.exists() && f.length() > 0
    }

    private fun onItemClick(item: Item) {
        val rows = mutableListOf<SheetRow>()
        rows.add(SheetRow("✏️  " + getString(R.string.opt_edit), false) { showForm(item) })
        if (item.type == T_SCAD && item.repeatMonths > 0) {
            rows.add(SheetRow("✅  " + getString(R.string.opt_renewed), false) { renew(item) })
        }
        if (item.type == T_GAR && receiptExists(item.id)) {
            rows.add(SheetRow("🧾  " + getString(R.string.opt_view_receipt), false) { viewReceipt(item) })
        }
        rows.add(SheetRow("🗑️  " + getString(R.string.opt_delete), true) { confirmDelete(item) })
        sheetList(item.name, rows)
    }

    private fun renew(item: Item) {
        val today = LocalDate.now()
        item.date = item.date.plusMonths(item.repeatMonths.toLong())
        while (item.date.isBefore(today)) item.date = item.date.plusMonths(item.repeatMonths.toLong())
        item.notified = NOT_YET
        Repo.save(this)
        syncCalendar()
        refresh(false)
        Toast.makeText(this, getString(R.string.toast_next_deadline, fmtDate(item.date)), Toast.LENGTH_LONG).show()
    }

    private fun viewReceipt(item: Item) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", receiptFile(item.id))
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "image/jpeg")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_cannot_open_photo, Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDelete(item: Item) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(item.name)
            .setPositiveButton(R.string.opt_delete) { _, _ ->
                val ev = item.eventId
                Repo.all(this).remove(item)
                receiptFile(item.id).delete()
                Repo.save(this)
                refresh(false)
                if (ev >= 0) {
                    val app = applicationContext
                    thread { CalendarSync.deleteEvent(app, ev) }
                }
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun syncCalendar() {
        val app = applicationContext
        thread { CalendarSync.syncAll(app) }
    }

    // ---------- aggiungere ----------

    private fun docPhotoUri(): Uri {
        val dir = File(cacheDir, "scan")
        dir.mkdirs()
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "photo.jpg"))
    }

    private fun showAddSheet() {
        val rows = mutableListOf<SheetRow>()
        rows.add(SheetRow("✍️  " + getString(R.string.add_manual), false) { showForm(null) })
        if (tab == T_ABB) {
            rows.add(SheetRow("📲  " + getString(R.string.add_from_apps), false) { showAppPicker() })
        }
        rows.add(SheetRow("📷  " + getString(R.string.add_scan_photo), false) {
            try {
                takeDocPhoto.launch(docPhotoUri())
            } catch (e: Exception) {
                Toast.makeText(this, R.string.toast_camera_unavailable, Toast.LENGTH_LONG).show()
            }
        })
        rows.add(SheetRow("🖼️  " + getString(R.string.add_scan_gallery), false) { pickDocument.launch("image/*") })
        rows.add(SheetRow("📄  " + getString(R.string.add_scan_pdf), false) { pickDocument.launch("application/pdf") })
        sheetList(
            getString(
                when (tab) {
                    T_SCAD -> R.string.form_new_deadline
                    T_ABB -> R.string.form_new_sub
                    else -> R.string.form_new_warranty
                }
            ),
            rows
        )
    }

    private fun importDocument(uri: Uri) {
        val scanType = tab
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(24), dp(24), dp(24), dp(24))
        row.addView(ProgressBar(this))
        val msg = TextView(this)
        msg.text = "   " + getString(R.string.scan_reading)
        msg.textSize = 16f
        row.addView(msg)
        val dlg = AlertDialog.Builder(this).setView(row).setCancelable(false).create()
        dlg.show()

        val act = this
        thread {
            try {
                val text = DocReader.readText(applicationContext, uri)
                val scan = DocParser.parse(text, act, scanType)
                runOnUiThread {
                    dlg.dismiss()
                    if (text.isBlank()) {
                        AlertDialog.Builder(act)
                            .setTitle(R.string.scan_unreadable_title)
                            .setMessage(R.string.scan_unreadable_msg)
                            .setPositiveButton(R.string.btn_enter_manually) { _, _ -> showForm(null) }
                            .setNegativeButton(R.string.btn_cancel, null)
                            .show()
                    } else {
                        showForm(null, scan)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlg.dismiss()
                    AlertDialog.Builder(act)
                        .setTitle(R.string.scan_error_title)
                        .setMessage(getString(R.string.scan_error_msg, e.message ?: getString(R.string.scan_unknown_error)))
                        .setPositiveButton(R.string.btn_ok, null)
                        .show()
                }
            }
        }
    }

    private fun showAppPicker() {
        val all = AppIcons.apps(this)
        if (all.isEmpty()) {
            Toast.makeText(this, R.string.picker_none, Toast.LENGTH_LONG).show()
            showForm(null)
            return
        }
        val shown = all.toMutableList()
        val ctx = this

        val adapter = object : ArrayAdapter<AppIcons.AppInfo>(ctx, 0, shown) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row: LinearLayout
                if (convertView is LinearLayout) {
                    row = convertView
                } else {
                    row = LinearLayout(ctx)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.setPadding(dp(16), dp(8), dp(16), dp(8))
                    val iv = ImageView(ctx)
                    iv.id = 1001
                    row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                    val tv = TextView(ctx)
                    tv.id = 1002
                    tv.textSize = 16f
                    tv.setPadding(dp(16), 0, 0, 0)
                    row.addView(tv)
                }
                val info = shown[position]
                val icon = try {
                    ctx.packageManager.getApplicationIcon(info.pkg)
                } catch (e: Exception) {
                    null
                }
                row.findViewById<ImageView>(1001).setImageDrawable(icon)
                row.findViewById<TextView>(1002).text = info.label
                return row
            }
        }

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        val search = EditText(ctx)
        search.hint = getString(R.string.picker_search)
        search.inputType = InputType.TYPE_CLASS_TEXT
        box.addView(search)
        val list = ListView(ctx)
        list.adapter = adapter
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim() ?: ""
                shown.clear()
                shown.addAll(all.filter { it.label.contains(q, ignoreCase = true) })
                adapter.notifyDataSetChanged()
            }
        })

        val dlg = AlertDialog.Builder(ctx)
            .setTitle(R.string.picker_title)
            .setView(box)
            .setNegativeButton(R.string.btn_cancel, null)
            .create()
        list.setOnItemClickListener { _, _, pos, _ ->
            val chosen = shown[pos]
            dlg.dismiss()
            showForm(null, null, chosen.label)
        }
        dlg.show()
    }

    // ---------- modulo (foglio dal basso) ----------

    private fun showForm(existing: Item?, prefill: Scan? = null, presetName: String? = null) {
        val type = existing?.type ?: tab
        val id = existing?.id ?: UUID.randomUUID().toString()
        val today = LocalDate.now()
        var date: LocalDate = when {
            existing != null -> if (type == T_GAR) (existing.purchase ?: today) else existing.date
            type == T_GAR -> prefill?.purchaseDate ?: today
            else -> prefill?.date ?: today
        }

        val sheet = BottomSheetDialog(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(20), dp(24), dp(32))

        val titleView = TextView(this)
        titleView.text = getString(
            when (type) {
                T_SCAD -> if (existing == null) R.string.form_new_deadline else R.string.form_edit_deadline
                T_ABB -> if (existing == null) R.string.form_new_sub else R.string.form_edit_sub
                else -> if (existing == null) R.string.form_new_warranty else R.string.form_edit_warranty
            }
        )
        titleView.textSize = 26f
        titleView.setTypeface(null, Typeface.BOLD)
        titleView.setTextColor(onSurface())
        box.addView(titleView)

        fun addField(label: String, v: View) {
            val l = TextView(this@MainActivity)
            l.text = label
            l.textSize = 13f
            l.setTypeface(null, Typeface.BOLD)
            l.setTextColor(onSurfaceVariant())
            l.setPadding(dp(4), dp(18), 0, dp(6))
            box.addView(l)
            box.addView(v)
        }

        if (prefill != null) {
            val sb = StringBuilder(getString(R.string.scan_info))
            val noDate = if (type == T_GAR) prefill.purchaseDate == null else prefill.date == null
            if (noDate) sb.append("\n").append(getString(R.string.scan_no_date))
            if (type != T_GAR && prefill.amount == null) sb.append("\n").append(getString(R.string.scan_no_amount))
            if (type != T_GAR && prefill.otherDates.isNotEmpty()) {
                sb.append("\n").append(
                    getString(R.string.scan_other_dates, prefill.otherDates.joinToString(", ") { fmtDate(it) })
                )
            }
            if (type != T_GAR && prefill.otherAmounts.isNotEmpty()) {
                sb.append("\n").append(
                    getString(R.string.scan_other_amounts, prefill.otherAmounts.joinToString(", ") { fmtMoney(this, it) })
                )
            }
            val info = TextView(this)
            info.text = sb.toString()
            info.textSize = 13f
            info.setTextColor(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnPrimaryContainer, Color.BLACK)
            )
            val ibg = GradientDrawable()
            ibg.cornerRadius = dp(14).toFloat()
            ibg.setColor(
                MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimaryContainer, Color.LTGRAY)
            )
            info.background = ibg
            info.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            box.addView(info, lp)
        }

        // ripetizione e categoria
        val allRep = resources.getStringArray(R.array.repeat_labels).toList()
        val repVals = if (type == T_ABB) REPEAT_VALUES.drop(1) else REPEAT_VALUES
        val repLabs = if (type == T_ABB) allRep.drop(1) else allRep
        val startRep = when {
            existing != null -> existing.repeatMonths
            type == T_ABB -> prefill?.repeatMonths ?: 1
            else -> 0
        }
        val repChoice = choiceField(repLabs, repVals.indexOf(startRep).coerceAtLeast(0), getString(R.string.field_repeat))
        val catLabels = SCAD_EMOJI.indices.map { SCAD_EMOJI[it] + "  " + scadName(this, it) }
        val catStart = (existing?.category ?: prefill?.category ?: 0).coerceIn(0, SCAD_EMOJI.size - 1)
        val catChoice = choiceField(catLabels, catStart, getString(R.string.field_type)) { pos ->
            if (existing == null) repChoice.set(repVals.indexOf(SCAD_DEFAULT_REPEAT[pos]).coerceAtLeast(0))
        }
        if (type == T_SCAD && existing == null) {
            repChoice.set(repVals.indexOf(SCAD_DEFAULT_REPEAT[catStart]).coerceAtLeast(0))
        }

        // nome (con suggerimenti per gli abbonamenti)
        val etName: EditText = if (type == T_ABB) {
            val ac = AutoCompleteTextView(this)
            ac.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Brands.suggestions(this)))
            ac.threshold = 1
            ac
        } else {
            EditText(this)
        }
        styleField(etName)
        etName.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        etName.setText(existing?.name ?: presetName ?: (if (type == T_SCAD) prefill?.name else null) ?: "")
        etName.hint = getString(
            when (type) {
                T_SCAD -> R.string.hint_deadline
                T_ABB -> R.string.hint_sub
                else -> R.string.hint_warranty
            }
        )

        val etCost = EditText(this)
        styleField(etCost)
        etCost.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        etCost.hint = "0.00"
        val prefillAmount = if (existing == null && type != T_GAR) prefill?.amount else null
        if (existing != null && existing.cost > 0) {
            etCost.setText(String.format(Locale.getDefault(), "%.2f", existing.cost))
        } else if (prefillAmount != null) {
            etCost.setText(String.format(Locale.getDefault(), "%.2f", prefillAmount))
        }

        val etStore = EditText(this)
        styleField(etStore)
        etStore.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        etStore.hint = getString(R.string.hint_store)
        etStore.setText(existing?.store ?: prefill?.storeGuess ?: "")

        val etMonths = EditText(this)
        styleField(etMonths)
        etMonths.inputType = InputType.TYPE_CLASS_NUMBER
        etMonths.setText((existing?.months ?: prefill?.warrantyMonths ?: 24).toString())

        // data
        val btnDate = TextView(this)
        styleField(btnDate)
        btnDate.text = "📅  " + fmtDate(date)
        btnDate.setOnClickListener {
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    date = LocalDate.of(y, m + 1, d)
                    btnDate.text = "📅  " + fmtDate(date)
                },
                date.year, date.monthValue - 1, date.dayOfMonth
            ).show()
        }

        // abbonamenti: riquadro con l'icona del servizio mentre scrivi
        val preview = TextView(this)
        val nameRow = LinearLayout(this)
        if (type == T_ABB) {
            Brands.show(preview, etName.text.toString())
            etName.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    Brands.show(preview, s?.toString() ?: "")
                }
            })
            nameRow.orientation = LinearLayout.HORIZONTAL
            nameRow.gravity = Gravity.CENTER_VERTICAL
            nameRow.addView(preview)
            nameRow.addView(etName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        // garanzie: foto dello scontrino
        val btnPhoto = outlined(
            if (receiptExists(id)) getString(R.string.photo_present) else getString(R.string.photo_take)
        )
        btnPhoto.setOnClickListener {
            photoButton = btnPhoto
            try {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", receiptFile(id))
                takePicture.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(this, R.string.toast_camera_unavailable, Toast.LENGTH_LONG).show()
            }
        }

        when (type) {
            T_SCAD -> {
                addField(getString(R.string.field_type), catChoice.tv)
                addField(getString(R.string.field_name), etName)
                addField(getString(R.string.field_due_date), btnDate)
                addField(getString(R.string.field_amount_due), etCost)
                addField(getString(R.string.field_repeat), repChoice.tv)
            }
            T_ABB -> {
                addField(getString(R.string.field_service), nameRow)
                addField(getString(R.string.field_price), etCost)
                addField(getString(R.string.field_renews), repChoice.tv)
                addField(getString(R.string.field_next_renewal), btnDate)
            }
            else -> {
                addField(getString(R.string.field_product), etName)
                addField(getString(R.string.field_store), etStore)
                addField(getString(R.string.field_purchase_date), btnDate)
                addField(getString(R.string.field_warranty_months), etMonths)
                addField(getString(R.string.field_receipt), btnPhoto)
            }
        }

        val save = MaterialButton(this)
        save.text = getString(R.string.btn_save)
        save.textSize = 17f
        save.isAllCaps = false
        save.cornerRadius = dp(28)
        val saveLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        saveLp.topMargin = dp(28)
        box.addView(save, saveLp)

        val cancel = outlined(getString(R.string.btn_cancel))
        val cancelLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        cancelLp.topMargin = dp(10)
        box.addView(cancel, cancelLp)
        cancel.setOnClickListener { sheet.dismiss() }

        save.setOnClickListener {
            val name = etName.text.toString().trim()
            val finalName = if (name.isEmpty() && type == T_SCAD) scadName(this, catChoice.index) else name
            if (finalName.isEmpty()) {
                Toast.makeText(this, R.string.toast_name_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val cost = etCost.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
            val rep = repVals[repChoice.index]

            val item = existing ?: Item(id = id, type = type, name = finalName, date = date)
            val oldDate = existing?.date
            item.name = finalName
            when (type) {
                T_SCAD -> {
                    item.category = catChoice.index
                    item.date = date
                    item.cost = cost
                    item.repeatMonths = rep
                }
                T_ABB -> {
                    item.date = date
                    item.cost = cost
                    item.repeatMonths = rep
                }
                else -> {
                    val m = (etMonths.text.toString().toIntOrNull() ?: 24).coerceIn(1, 600)
                    item.store = etStore.text.toString().trim()
                    item.purchase = date
                    item.months = m
                    item.date = date.plusMonths(m.toLong())
                }
            }
            if (oldDate != null && oldDate != item.date) item.notified = NOT_YET
            if (existing == null) Repo.all(this).add(item)
            Repo.save(this)
            syncCalendar()
            refresh(false)
            it.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
            sheet.dismiss()
        }

        val scroll = ScrollView(this)
        scroll.addView(box)
        sheet.setContentView(scroll)
        sheet.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        sheet.behavior.skipCollapsed = true
        sheet.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        sheet.show()
    }

    // ---------- blocco dell'app ----------

    private fun checkLock() {
        val now = SystemClock.elapsedRealtime()
        if (Prefs.lock(this) && (!unlocked || now - leftAt > 120_000L)) {
            unlocked = false
            lockOverlay.visibility = View.VISIBLE
            if (!promptShowing) promptUnlock()
        } else {
            lockOverlay.visibility = View.GONE
        }
    }

    private fun promptUnlock() {
        promptShowing = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    unlocked = true
                    leftAt = SystemClock.elapsedRealtime()
                    lockOverlay.visibility = View.GONE
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    promptShowing = false
                    // se il telefono non ha piu' un blocco schermo, si disattiva il blocco per non chiudere fuori l'utente
                    if (errorCode == BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL ||
                        errorCode == BiometricPrompt.ERROR_NO_BIOMETRICS ||
                        errorCode == BiometricPrompt.ERROR_HW_NOT_PRESENT
                    ) {
                        Prefs.sp(this@MainActivity).edit().putBoolean("app_lock", false).apply()
                        unlocked = true
                        lockOverlay.visibility = View.GONE
                    }
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.lock_title))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}
