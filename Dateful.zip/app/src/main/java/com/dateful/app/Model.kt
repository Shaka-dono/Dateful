package com.dateful.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.temporal.ChronoUnit
import java.util.Currency
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

const val T_SCAD = 0
const val T_ABB = 1
const val T_GAR = 2
const val NOT_YET = 999

val SCAD_EMOJI = listOf("🚗", "🔧", "🛡️", "🛠️", "🔥", "🏛️", "📌")
val SCAD_COLORS = listOf(0xFF2563EB, 0xFF7C3AED, 0xFF16A34A, 0xFFEA580C, 0xFFDC2626, 0xFF0D9488, 0xFF64748B)
    .map { it.toInt() }
val SCAD_DEFAULT_REPEAT = listOf(12, 24, 12, 12, 12, 6, 0)
val REPEAT_VALUES = listOf(0, 1, 2, 3, 6, 12, 24)

fun scadName(c: Context, i: Int): String =
    c.resources.getStringArray(R.array.scad_names)[i.coerceIn(0, SCAD_EMOJI.size - 1)]

fun repeatLabel(c: Context, m: Int): String {
    val i = REPEAT_VALUES.indexOf(m)
    return c.resources.getStringArray(R.array.repeat_labels)[if (i < 0) 0 else i]
}

fun fmtDate(d: LocalDate): String = d.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))

fun fmtMoney(c: Context, v: Double): String {
    val nf = NumberFormat.getCurrencyInstance(Locale.getDefault())
    try {
        nf.currency = Currency.getInstance(Prefs.currency(c))
    } catch (e: Exception) {
        // si usa la valuta del telefono
    }
    return nf.format(v)
}

fun daysText(c: Context, d: Long): String = when {
    d < 0 -> c.getString(R.string.days_overdue, -d)
    d == 0L -> c.getString(R.string.days_today)
    d == 1L -> c.getString(R.string.days_tomorrow)
    else -> c.getString(R.string.days_in, d)
}

data class Item(
    val id: String = UUID.randomUUID().toString(),
    var type: Int,
    var name: String,
    var category: Int = 0,
    var date: LocalDate,
    var cost: Double = 0.0,
    var repeatMonths: Int = 0,
    var store: String = "",
    var purchase: LocalDate? = null,
    var months: Int = 24,
    var notified: Int = NOT_YET,
    var eventId: Long = -1L
) {
    fun daysLeft(): Long = ChronoUnit.DAYS.between(LocalDate.now(), date)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("type", type)
        .put("name", name)
        .put("category", category)
        .put("date", date.toString())
        .put("cost", cost)
        .put("repeat", repeatMonths)
        .put("store", store)
        .put("purchase", purchase?.toString() ?: JSONObject.NULL)
        .put("months", months)
        .put("notified", notified)
        .put("event", eventId)

    companion object {
        fun fromJson(o: JSONObject): Item = Item(
            id = o.getString("id"),
            type = o.getInt("type"),
            name = o.getString("name"),
            category = o.optInt("category", 0),
            date = LocalDate.parse(o.getString("date")),
            cost = o.optDouble("cost", 0.0),
            repeatMonths = o.optInt("repeat", 0),
            store = o.optString("store", ""),
            purchase = if (o.isNull("purchase")) null else LocalDate.parse(o.getString("purchase")),
            months = o.optInt("months", 24),
            notified = o.optInt("notified", NOT_YET),
            eventId = o.optLong("event", -1L)
        )
    }
}

object Repo {
    private var items: MutableList<Item>? = null

    private fun file(c: Context) = File(c.filesDir, "items.json")

    @Synchronized
    fun all(c: Context): MutableList<Item> {
        items?.let { return it }
        val list: MutableList<Item> = CopyOnWriteArrayList()
        val f = file(c)
        if (f.exists()) {
            try {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) list.add(Item.fromJson(arr.getJSONObject(i)))
            } catch (e: Exception) {
                // file illeggibile: si riparte vuoti
            }
        }
        items = list
        return list
    }

    @Synchronized
    fun save(c: Context) {
        val list = items ?: return
        val arr = JSONArray()
        for (item in list) arr.put(item.toJson())
        val tmp = File(c.filesDir, "items.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file(c))) file(c).writeText(arr.toString())
    }

    // Gli abbonamenti si rinnovano da soli: la data avanza finche' non e' nel futuro.
    @Synchronized
    fun rollSubscriptions(c: Context): Boolean {
        val today = LocalDate.now()
        var changed = false
        for (item in all(c)) {
            if (item.type == T_ABB && item.repeatMonths > 0) {
                while (item.date.isBefore(today)) {
                    item.date = item.date.plusMonths(item.repeatMonths.toLong())
                    item.notified = NOT_YET
                    changed = true
                }
            }
        }
        if (changed) save(c)
        return changed
    }
}
