package com.dateful.app

import android.Manifest
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.HapticFeedbackConstants
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.core.os.LocaleListCompat
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import java.time.LocalDate
import kotlin.concurrent.thread

class SettingsActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private var suppress = false

    private val calPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.all { it }) {
                Prefs.sp(this).edit().putBoolean("cal_enabled", true).apply()
                autoPickCalendar()
                val app = applicationContext
                thread { CalendarSync.syncAll(app) }
            } else {
                toast(getString(R.string.toast_cal_denied))
            }
            render()
        }

    private val createBackup =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if (uri != null) doExport(uri, false)
        }

    private val createCsv =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            if (uri != null) doExport(uri, true)
        }

    private val openBackup =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) doImport(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<TextView>(R.id.tvSettingsTitle).text = getString(R.string.set_title)
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        list = findViewById(R.id.settingsList)
        render()
    }

    // ---------- aiuti ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun arr(id: Int): List<String> = resources.getStringArray(id).toList()

    private fun primaryText(): Int =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, Color.BLACK)

    private fun secondary(): Int =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

    private fun outline(): Int =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutlineVariant, Color.LTGRAY)

    private fun autoPickCalendar() {
        val sp = Prefs.sp(this)
        val cals = CalendarSync.calendars(this)
        val current = sp.getString("cal_id", "") ?: ""
        if (cals.isNotEmpty() && cals.none { it.first.toString() == current }) {
            sp.edit().putString("cal_id", cals[0].first.toString()).apply()
        }
    }

    private fun newCard(title: String): LinearLayout {
        val t = TextView(this)
        t.text = title.uppercase()
        t.textSize = 12.5f
        t.setTypeface(null, Typeface.BOLD)
        t.letterSpacing = 0.04f
        t.setTextColor(secondary())
        t.setPadding(dp(32), dp(24), dp(16), dp(8))
        list.addView(t)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card_plain)
        card.clipToOutline = true
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), 0, dp(16), 0)
        list.addView(card, lp)
        return card
    }

    private fun valueText(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 15f
        v.setTextColor(secondary())
        return v
    }

    private fun addRow(
        card: LinearLayout, title: String, summary: String?, trailing: View?,
        onClick: (() -> Unit)?, destructive: Boolean = false
    ) {
        if (card.childCount > 0) {
            val div = View(this)
            div.setBackgroundColor(outline())
            val dl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
            dl.marginStart = dp(16)
            card.addView(div, dl)
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(14))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val tt = TextView(this)
        tt.text = title
        tt.textSize = 17f
        tt.setTextColor(if (destructive) Color.parseColor("#DC2626") else primaryText())
        col.addView(tt)
        if (summary != null) {
            val st = TextView(this)
            st.text = summary
            st.textSize = 13f
            st.setTextColor(secondary())
            st.setPadding(0, dp(2), 0, 0)
            col.addView(st)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)

        if (onClick != null) {
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                onClick()
            }
        }
        card.addView(row)
    }

    private fun actionRow(
        card: LinearLayout, title: String, summary: String?, destructive: Boolean, onClick: () -> Unit
    ) = addRow(card, title, summary, null, onClick, destructive)

    private fun choiceRow(
        card: LinearLayout, title: String, entries: List<String>, values: List<String>,
        current: String, onPick: (String) -> Unit
    ) {
        var idx = values.indexOf(current).coerceAtLeast(0)
        val v = valueText(entries[idx] + "  ›")
        addRow(card, title, null, v, {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(entries.toTypedArray(), idx) { d, w ->
                    idx = w
                    v.text = entries[w] + "  ›"
                    d.dismiss()
                    onPick(values[w])
                }
                .show()
        })
    }

    private fun multiRow(
        card: LinearLayout, title: String, summary: String?, entries: List<String>, values: List<String>,
        shown: List<String>, current: Set<String>, onSave: (Set<String>) -> Unit
    ) {
        var cur = current
        val v = valueText(shown.filterIndexed { i, _ -> values[i] in cur }.joinToString(", ") + "  ›")
        addRow(card, title, summary, v, {
            val checked = BooleanArray(values.size) { values[it] in cur }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMultiChoiceItems(entries.toTypedArray(), checked) { _, w, isChecked -> checked[w] = isChecked }
                .setPositiveButton(R.string.btn_ok) { _, _ ->
                    cur = values.filterIndexed { i, _ -> checked[i] }.toSet()
                    v.text = shown.filterIndexed { i, _ -> values[i] in cur }.joinToString(", ") + "  ›"
                    onSave(cur)
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
        })
    }

    // onToggle puo' rifiutare il cambio restituendo false
    private fun switchRow(
        card: LinearLayout, title: String, summary: String?, key: String, def: Boolean,
        onToggle: (Boolean) -> Boolean
    ) {
        val sw = MaterialSwitch(this)
        sw.isChecked = Prefs.sp(this).getBoolean(key, def)
        sw.setOnCheckedChangeListener { btn, checked ->
            if (!suppress) {
                if (onToggle(checked)) {
                    Prefs.sp(this).edit().putBoolean(key, checked).apply()
                } else {
                    suppress = true
                    btn.isChecked = !checked
                    suppress = false
                }
            }
        }
        addRow(card, title, summary, sw, { sw.toggle() })
    }

    // ---------- schermata ----------

    private fun render() {
        list.removeAllViews()
        val app = applicationContext
        val sp = Prefs.sp(this)

        // aspetto, lingua, valuta
        var card = newCard(getString(R.string.sec_appearance))
        choiceRow(
            card, getString(R.string.set_theme), arr(R.array.theme_entries),
            listOf("system", "light", "dark"), Prefs.theme(this)
        ) { v ->
            sp.edit().putString("theme", v).apply()
            list.post { recreate() }
        }
        choiceRow(
            card, getString(R.string.set_accent), arr(R.array.accent_entries),
            listOf("teal", "blue", "indigo", "purple", "pink", "red", "orange", "green", "dynamic"),
            Prefs.accent(this)
        ) { v ->
            sp.edit().putString("accent", v).apply()
            list.post { recreate() }
        }
        val locales = AppCompatDelegate.getApplicationLocales()
        val curLang = if (locales.isEmpty) "system" else (locales.get(0)?.language ?: "system")
        choiceRow(
            card, getString(R.string.set_language), arr(R.array.lang_entries),
            listOf("system", "en", "it"), curLang
        ) { v ->
            AppCompatDelegate.setApplicationLocales(
                if (v == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(v)
            )
        }
        choiceRow(
            card, getString(R.string.set_currency), arr(R.array.currency_entries),
            listOf("EUR", "USD", "GBP", "CHF"), Prefs.currency(this)
        ) { v -> sp.edit().putString("currency", v).apply() }

        // notifiche
        card = newCard(getString(R.string.sec_notifications))
        switchRow(card, getString(R.string.set_notif_enabled), getString(R.string.set_notif_enabled_sum), "notif_enabled", true) { true }
        choiceRow(
            card, getString(R.string.set_notif_hour),
            (6..22).map { String.format("%02d:00", it) }, (6..22).map { it.toString() },
            Prefs.notifHour(this).toString()
        ) { v ->
            sp.edit().putString("notif_hour", v).apply()
            Reminders.schedule(app)
        }
        val dayValues = listOf("60", "30", "14", "7", "3", "1", "0")
        multiRow(
            card, getString(R.string.set_notif_days), getString(R.string.set_notif_days_sum),
            arr(R.array.days_entries), dayValues, dayValues,
            Prefs.days(this, false).map { it.toString() }.toSet()
        ) { set -> sp.edit().putStringSet("notif_days", set).apply() }
        val daySubValues = listOf("14", "7", "3", "1", "0")
        multiRow(
            card, getString(R.string.set_notif_days_sub), getString(R.string.set_notif_days_sub_sum),
            arr(R.array.days_sub_entries), daySubValues, daySubValues,
            Prefs.days(this, true).map { it.toString() }.toSet()
        ) { set -> sp.edit().putStringSet("notif_days_sub", set).apply() }

        // calendario
        card = newCard(getString(R.string.sec_calendar))
        switchRow(card, getString(R.string.set_cal_enabled), getString(R.string.set_cal_enabled_sum), "cal_enabled", false) { on ->
            if (on) {
                if (!CalendarSync.granted(this)) {
                    calPerms.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
                    false
                } else {
                    autoPickCalendar()
                    thread { CalendarSync.syncAll(app) }
                    list.post { render() }
                    true
                }
            } else {
                true
            }
        }
        val calTypeLabels = arr(R.array.cal_types_entries)
        multiRow(
            card, getString(R.string.set_cal_types), null,
            calTypeLabels, listOf("0", "1", "2"), calTypeLabels,
            Prefs.calTypes(this).map { it.toString() }.toSet()
        ) { set ->
            sp.edit().putStringSet("cal_types", set).apply()
            thread { CalendarSync.syncAll(app) }
        }
        val cals = if (Prefs.calEnabled(this)) CalendarSync.calendars(this) else emptyList()
        if (cals.isEmpty()) {
            addRow(card, getString(R.string.set_cal_target), getString(R.string.set_cal_target_none), null, null)
        } else {
            choiceRow(
                card, getString(R.string.set_cal_target),
                cals.map { it.second }, cals.map { it.first.toString() }, Prefs.calId(this).toString()
            ) { v ->
                sp.edit().putString("cal_id", v).apply()
                thread {
                    CalendarSync.removeAll(app)
                    CalendarSync.syncAll(app)
                }
            }
        }
        actionRow(card, getString(R.string.set_cal_remove), getString(R.string.set_cal_remove_sum), false) {
            AlertDialog.Builder(this)
                .setTitle(R.string.dlg_remove_events_title)
                .setMessage(R.string.dlg_remove_events_msg)
                .setPositiveButton(R.string.dlg_remove) { _, _ ->
                    thread {
                        CalendarSync.removeAll(app)
                        runOnUiThread { toast(getString(R.string.toast_events_removed)) }
                    }
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
        }

        // sicurezza
        card = newCard(getString(R.string.sec_security))
        switchRow(card, getString(R.string.set_lock), getString(R.string.set_lock_sum), "app_lock", false) { on ->
            if (on) {
                val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
                if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
                    toast(getString(R.string.toast_lock_needs_screen_lock))
                    false
                } else {
                    true
                }
            } else {
                true
            }
        }

        // elenchi
        card = newCard(getString(R.string.sec_lists))
        choiceRow(
            card, getString(R.string.set_sort), arr(R.array.sort_entries),
            listOf("date", "name", "amount"), Prefs.sort(this)
        ) { v -> sp.edit().putString("sort", v).apply() }
        switchRow(card, getString(R.string.set_icons), getString(R.string.set_icons_sum), "icons_from_apps", true) { true }

        // dati
        card = newCard(getString(R.string.sec_data))
        actionRow(card, getString(R.string.set_export), getString(R.string.set_export_sum), false) {
            createBackup.launch("dateful-backup-" + LocalDate.now() + ".zip")
        }
        actionRow(card, getString(R.string.set_import), getString(R.string.set_import_sum), false) {
            openBackup.launch(arrayOf("*/*"))
        }
        actionRow(card, getString(R.string.set_csv), getString(R.string.set_csv_sum), false) {
            createCsv.launch("dateful-" + LocalDate.now() + ".csv")
        }
        actionRow(card, getString(R.string.set_wipe), getString(R.string.set_wipe_sum), true) {
            AlertDialog.Builder(this)
                .setTitle(R.string.dlg_wipe_title)
                .setMessage(R.string.dlg_wipe_msg)
                .setPositiveButton(R.string.dlg_wipe) { _, _ ->
                    thread {
                        CalendarSync.removeAll(app)
                        Backup.wipe(app)
                        runOnUiThread { toast(getString(R.string.toast_data_wiped)) }
                    }
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
        }

        // informazioni
        card = newCard(getString(R.string.sec_about))
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        addRow(card, getString(R.string.app_name), getString(R.string.about_summary, version), null, null)
    }

    // ---------- esporta e importa ----------

    private fun doExport(uri: Uri, csv: Boolean) {
        val app = applicationContext
        thread {
            val ok = try {
                app.contentResolver.openOutputStream(uri)!!.use { out ->
                    if (csv) Backup.exportCsv(app, out) else Backup.exportZip(app, out)
                }
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                toast(getString(if (ok) R.string.toast_file_saved else R.string.toast_file_failed))
            }
        }
    }

    private fun doImport(uri: Uri) {
        val app = applicationContext
        thread {
            val n = try {
                app.contentResolver.openInputStream(uri)!!.use { Backup.importZip(app, it) }
            } catch (e: Exception) {
                -1
            }
            if (n >= 0) CalendarSync.syncAll(app)
            runOnUiThread {
                toast(if (n >= 0) getString(R.string.toast_imported, n) else getString(R.string.toast_import_invalid))
            }
        }
    }
}
