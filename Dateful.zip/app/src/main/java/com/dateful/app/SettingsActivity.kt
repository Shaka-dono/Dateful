package com.dateful.app

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import java.time.LocalDate
import kotlin.concurrent.thread

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }
}

class SettingsFragment : PreferenceFragmentCompat(), SharedPreferences.OnSharedPreferenceChangeListener {

    private val calPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.all { it }) {
                findPreference<SwitchPreferenceCompat>("cal_enabled")?.isChecked = true
                loadCalendars()
            } else {
                toast("Senza il permesso non posso usare il calendario")
            }
        }

    private val createBackup =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if (uri != null) doExport(uri, false)
        }

    private val createCsv =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            if (uri != null) doExport(uri, true)
        }

    private val openBackup =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) doImport(uri)
        }

    private fun toast(msg: String) {
        val c = context ?: return
        Toast.makeText(c, msg, Toast.LENGTH_LONG).show()
    }

    private fun hasCalPerms(): Boolean {
        val c = requireContext()
        return ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
        val ctx = requireContext()
        val app = ctx.applicationContext

        findPreference<ListPreference>("theme")?.setOnPreferenceChangeListener { _, _ ->
            view?.post { activity?.recreate() }
            true
        }
        findPreference<ListPreference>("accent")?.setOnPreferenceChangeListener { _, _ ->
            view?.post { activity?.recreate() }
            true
        }
        findPreference<ListPreference>("notif_hour")?.setOnPreferenceChangeListener { _, _ ->
            view?.postDelayed({ Reminders.schedule(app) }, 300)
            true
        }

        findPreference<SwitchPreferenceCompat>("cal_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            if (newValue == true) {
                if (!hasCalPerms()) {
                    calPerms.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
                    false
                } else {
                    loadCalendars()
                    true
                }
            } else {
                true
            }
        }

        findPreference<SwitchPreferenceCompat>("app_lock")?.setOnPreferenceChangeListener { _, newValue ->
            if (newValue == true) {
                val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
                if (BiometricManager.from(ctx).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
                    toast("Prima imposta un blocco schermo (impronta, PIN o sequenza) nelle impostazioni del telefono")
                    false
                } else {
                    true
                }
            } else {
                true
            }
        }

        findPreference<Preference>("cal_remove")?.setOnPreferenceClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Rimuovere gli eventi?")
                .setMessage("Cancello dal calendario tutti gli eventi creati da Dateful. Le tue voci nell'app restano.")
                .setPositiveButton("Rimuovi") { _, _ ->
                    thread {
                        CalendarSync.removeAll(app)
                        activity?.runOnUiThread { toast("Eventi rimossi dal calendario") }
                    }
                }
                .setNegativeButton("Annulla", null)
                .show()
            true
        }

        findPreference<Preference>("export")?.setOnPreferenceClickListener {
            createBackup.launch("dateful-backup-" + LocalDate.now() + ".zip")
            true
        }
        findPreference<Preference>("export_csv")?.setOnPreferenceClickListener {
            createCsv.launch("dateful-" + LocalDate.now() + ".csv")
            true
        }
        findPreference<Preference>("import")?.setOnPreferenceClickListener {
            openBackup.launch(arrayOf("*/*"))
            true
        }
        findPreference<Preference>("wipe")?.setOnPreferenceClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Cancellare tutto?")
                .setMessage("Elimino scadenze, abbonamenti, garanzie e foto degli scontrini. Non si può annullare: esporta prima i dati se ti servono.")
                .setPositiveButton("Cancella") { _, _ ->
                    thread {
                        CalendarSync.removeAll(app)
                        Backup.wipe(app)
                        activity?.runOnUiThread { toast("Dati cancellati") }
                    }
                }
                .setNegativeButton("Annulla", null)
                .show()
            true
        }

        val version = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findPreference<Preference>("about")?.summary =
            "Versione $version. I tuoi dati restano sul telefono."

        loadCalendars()
    }

    private fun loadCalendars() {
        val p = findPreference<ListPreference>("cal_id") ?: return
        val cals = CalendarSync.calendars(requireContext())
        p.entries = cals.map { it.second }.toTypedArray()
        p.entryValues = cals.map { it.first.toString() }.toTypedArray()
        if (cals.isNotEmpty() && p.value.isNullOrEmpty()) p.value = cals[0].first.toString()
        p.isEnabled = cals.isNotEmpty()
        if (cals.isEmpty()) {
            p.setSummaryProvider(null)
            p.summary = "Attiva prima \"Aggiungi al calendario\""
        } else {
            p.setSummaryProvider(ListPreference.SimpleSummaryProvider.getInstance())
        }
    }

    override fun onResume() {
        super.onResume()
        preferenceManager.sharedPreferences?.registerOnSharedPreferenceChangeListener(this)
        loadCalendars()
    }

    override fun onPause() {
        super.onPause()
        preferenceManager.sharedPreferences?.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        val app = context?.applicationContext ?: return
        when (key) {
            "cal_enabled", "cal_types" -> thread { CalendarSync.syncAll(app) }
            "cal_id" -> thread {
                CalendarSync.removeAll(app)
                CalendarSync.syncAll(app)
            }
        }
    }

    private fun doExport(uri: Uri, csv: Boolean) {
        val app = requireContext().applicationContext
        thread {
            val ok = try {
                app.contentResolver.openOutputStream(uri)!!.use { out ->
                    if (csv) Backup.exportCsv(app, out) else Backup.exportZip(app, out)
                }
                true
            } catch (e: Exception) {
                false
            }
            activity?.runOnUiThread {
                toast(if (ok) "File salvato" else "Non sono riuscito a salvare il file")
            }
        }
    }

    private fun doImport(uri: Uri) {
        val app = requireContext().applicationContext
        thread {
            val n = try {
                app.contentResolver.openInputStream(uri)!!.use { Backup.importZip(app, it) }
            } catch (e: Exception) {
                -1
            }
            if (n >= 0) CalendarSync.syncAll(app)
            activity?.runOnUiThread {
                toast(if (n >= 0) "Importate $n voci" else "File non valido: scegli un file esportato da Dateful")
            }
        }
    }
}
