package com.dateful.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.time.LocalDate

/** Legge il testo da foto o PDF, tutto sul telefono (nessuna connessione). */
object DocReader {

    fun readText(c: Context, uri: Uri): String {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val sb = StringBuilder()
            for (bmp in bitmaps(c, uri)) {
                val res = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
                sb.append(res.text).append("\n")
            }
            return sb.toString()
        } finally {
            rec.close()
        }
    }

    private fun bitmaps(c: Context, uri: Uri): List<Bitmap> =
        if (isPdf(c, uri)) pdfPages(c, uri) else listOf(imageBitmap(c, uri))

    private fun isPdf(c: Context, uri: Uri): Boolean {
        val head = ByteArray(5)
        val n = c.contentResolver.openInputStream(uri)?.use { it.read(head) } ?: 0
        return n >= 4 && String(head, 0, 4, Charsets.ISO_8859_1) == "%PDF"
    }

    private fun pdfPages(c: Context, uri: Uri): List<Bitmap> {
        val tmp = File(c.cacheDir, "scan/doc.pdf")
        tmp.parentFile?.mkdirs()
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        val out = mutableListOf<Bitmap>()
        ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val renderer = PdfRenderer(pfd)
            try {
                for (i in 0 until minOf(renderer.pageCount, 3)) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1800
                        val h = (page.height.toFloat() / page.width * w).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(bmp)
                    } finally {
                        page.close()
                    }
                }
            } finally {
                renderer.close()
            }
        }
        return out
    }

    private fun imageBitmap(c: Context, uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = c.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw Exception("Immagine non leggibile")

        val degrees = c.contentResolver.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }
}

data class Scan(
    val date: LocalDate?,
    val amount: Double?,
    val name: String,
    val category: Int,
    val otherDates: List<LocalDate>,
    val otherAmounts: List<Double>
)

/** Cerca scadenza, importo e tipo di documento nel testo letto. */
object DocParser {

    private val MONTHS = listOf(
        "gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno",
        "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"
    )
    private val NUM_DATE = Regex("""\b(\d{1,2})\s?[/.\-]\s?(\d{1,2})\s?[/.\-]\s?(\d{4}|\d{2})\b""")
    private val TXT_DATE = Regex(
        """\b(\d{1,2})\s+(gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)\s+(\d{4})\b""",
        RegexOption.IGNORE_CASE
    )
    private val AMOUNT = Regex("""(?<![\d.,])((?:\d{1,3}(?:\.\d{3})+)|\d+),(\d{2})(?!\d)""")

    private val DATE_POS = listOf(
        "scadenza", "scade", "entro il", "entro", "pagare entro", "pagamento entro",
        "termine", "data limite", "valido fino", "valida fino"
    )
    private val DATE_NEG = listOf(
        "emissione", "emessa", "emesso", "fattura del", "data fattura", "data documento",
        "periodo", "lettura", "nato", "notifica", "dal "
    )
    private val AMT_STRONG = listOf(
        "da pagare", "importo dovuto", "totale dovuto", "netto a pagare",
        "importo totale", "totale fattura", "totale bolletta", "totale documento"
    )
    private val AMT_WEAK = listOf("totale", "importo", "euro", "€", "sanzione", "pagare", "somma")
    private val AMT_NEG = listOf("iva", "imponibile", "acconto", "credito", "arrotond", "spese di", "quota")

    private class Hit(val value: LocalDate, val pos: Int)
    private class Cand(val value: Double, val score: Int)

    // posizione di FINE dell'ultima parola trovata, cosi' "da pagare" batte "pagare"
    private fun lastIdx(win: String, ks: List<String>): Int =
        ks.maxOfOrNull { val i = win.lastIndexOf(it); if (i < 0) -1 else i + it.length } ?: -1

    private fun score(win: String, strong: List<String>, weak: List<String>, neg: List<String>): Int {
        val s = lastIdx(win, strong)
        val w = lastIdx(win, weak)
        val n = lastIdx(win, neg)
        return when {
            s >= 0 && s >= w && s >= n -> 10
            w >= 0 && w >= n -> 5
            n >= 0 -> -4
            else -> 0
        }
    }

    private fun window(t: String, pos: Int, len: Int): String =
        t.substring(maxOf(0, pos - len), pos).lowercase()

    private fun findDates(t: String): List<Hit> {
        val out = mutableListOf<Hit>()
        for (m in NUM_DATE.findAll(t)) {
            try {
                var y = m.groupValues[3].toInt()
                if (y < 100) y += 2000
                out.add(Hit(LocalDate.of(y, m.groupValues[2].toInt(), m.groupValues[1].toInt()), m.range.first))
            } catch (e: Exception) {
                // data non valida: ignorata
            }
        }
        for (m in TXT_DATE.findAll(t)) {
            try {
                val mo = MONTHS.indexOf(m.groupValues[2].lowercase()) + 1
                out.add(Hit(LocalDate.of(m.groupValues[3].toInt(), mo, m.groupValues[1].toInt()), m.range.first))
            } catch (e: Exception) {
                // data non valida: ignorata
            }
        }
        return out
    }

    fun parse(raw: String): Scan {
        val t = raw.replace('\n', ' ').replace(Regex("\\s+"), " ")
        val low = raw.lowercase()
        val today = LocalDate.now()

        // scadenza
        val ds = findDates(t).filter { it.value.year in (today.year - 1)..(today.year + 5) }
        val scoredDates = ds.map { it to score(window(t, it.pos, 50), DATE_POS, emptyList(), DATE_NEG) }
        val bestByKeyword = scoredDates.filter { it.second > 0 }.maxByOrNull { it.second }?.first?.value
        val chosenDate = bestByKeyword
            ?: ds.map { it.value }.filter { !it.isBefore(today) }.minOrNull()
            ?: ds.map { it.value }.maxOrNull()

        // importo
        val amts = AMOUNT.findAll(t).mapNotNull { m ->
            val v = (m.groupValues[1].replace(".", "") + "." + m.groupValues[2]).toDoubleOrNull()
            if (v == null || v < 0.5 || v > 1_000_000) null
            else Cand(v, score(window(t, m.range.first, 45), AMT_STRONG, AMT_WEAK, AMT_NEG))
        }.toList()
        val chosenAmount = amts.maxWithOrNull(compareBy<Cand>({ it.score }, { it.value }))?.value

        // tipo di documento
        fun has(vararg k: String) = k.any { low.contains(it) }
        val kind: Pair<String, Int> = when {
            has("verbale", "violazione", "codice della strada", "contravvenzione") -> "Multa" to 6
            has("kwh", "energia elettrica") -> "Bolletta luce" to 6
            has("smc", "gas naturale") -> "Bolletta gas" to 6
            has("servizio idrico", "acquedotto") -> "Bolletta acqua" to 6
            has("bolletta") -> "Bolletta" to 6
            has("tassa automobilistica", "bollo auto") -> "Bollo auto" to 0
            has("revisione") -> "Revisione" to 1
            has("polizza", "assicurazione") -> "Assicurazione" to 2
            has("tagliando") -> "Tagliando" to 3
            has("caldaia", "bollino blu") -> "Caldaia" to 4
            low.contains(Regex("\\b(imu|tari|tasi)\\b")) -> "Tasse casa" to 5
            has("fattura") -> "Fattura" to 6
            else -> "Documento" to 6
        }

        return Scan(
            date = chosenDate,
            amount = chosenAmount,
            name = kind.first,
            category = kind.second,
            otherDates = ds.map { it.value }.distinct().filter { it != chosenDate }.sorted().take(4),
            otherAmounts = amts.map { it.value }.distinct().filter { it != chosenAmount }.sortedDescending().take(4)
        )
    }
}
