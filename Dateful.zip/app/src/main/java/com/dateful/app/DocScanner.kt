package com.dateful.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.time.LocalDate
import java.util.Locale

/** Legge il testo da foto o PDF, tutto sul telefono (nessuna connessione). */
object DocReader {

    fun readText(c: Context, uri: Uri): String {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val sb = StringBuilder()
            for (bmp in bitmaps(c, uri)) {
                val res = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
                sb.append(res.text).append("\n")
            }
            return sb.toString()
        } finally {
            rec.close()
        }
    }

    private fun bitmaps(c: Context, uri: Uri): List<Bitmap> =
        if (isPdf(c, uri)) pdfPages(c, uri) else listOf(imageBitmap(c, uri))

    private fun isPdf(c: Context, uri: Uri): Boolean {
        val head = ByteArray(5)
        val n = c.contentResolver.openInputStream(uri)?.use { it.read(head) } ?: 0
        return n >= 4 && String(head, 0, 4, Charsets.ISO_8859_1) == "%PDF"
    }

    private fun pdfPages(c: Context, uri: Uri): List<Bitmap> {
        val tmp = File(c.cacheDir, "scan/doc.pdf")
        tmp.parentFile?.mkdirs()
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        val out = mutableListOf<Bitmap>()
        ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val renderer = PdfRenderer(pfd)
            try {
                for (i in 0 until minOf(renderer.pageCount, 3)) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1800
                        val h = (page.height.toFloat() / page.width * w).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(bmp)
                    } finally {
                        page.close()
                    }
                }
            } finally {
                renderer.close()
            }
        }
        return out
    }

    private fun imageBitmap(c: Context, uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = c.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw Exception("Immagine non leggibile")

        val degrees = c.contentResolver.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }
}

data class Scan(
    val date: LocalDate?,
    val amount: Double?,
    val name: String,
    val category: Int,
    val otherDates: List<LocalDate>,
    val otherAmounts: List<Double>,
    val purchaseDate: LocalDate?,
    val warrantyMonths: Int?,
    val repeatMonths: Int?,
    val storeGuess: String?
)

/** Cerca scadenza, importo e tipo di documento nel testo letto (italiano e inglese). */
object DocParser {

    private val MONTHS: Map<String, Int> = mapOf(
        "january" to 1, "february" to 2, "march" to 3, "april" to 4, "june" to 6, "july" to 7,
        "august" to 8, "september" to 9, "october" to 10, "november" to 11, "december" to 12,
        "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "may" to 5, "jun" to 6, "jul" to 7,
        "aug" to 8, "sep" to 9, "sept" to 9, "oct" to 10, "nov" to 11, "dec" to 12,
        "gennaio" to 1, "febbraio" to 2, "marzo" to 3, "aprile" to 4, "maggio" to 5, "giugno" to 6,
        "luglio" to 7, "agosto" to 8, "settembre" to 9, "ottobre" to 10, "novembre" to 11, "dicembre" to 12,
        "gen" to 1, "mag" to 5, "giu" to 6, "lug" to 7, "ago" to 8, "set" to 9, "ott" to 10, "dic" to 12
    )
    private val MONTH_ALT = MONTHS.keys.sortedByDescending { it.length }.joinToString("|")

    private val NUM_DATE = Regex("""\b(\d{1,2})\s?[/.\-]\s?(\d{1,2})\s?[/.\-]\s?(\d{4}|\d{2})\b""")
    private val DMY = Regex("""\b(\d{1,2})(?:st|nd|rd|th)?\s+($MONTH_ALT)\.?,?\s+(\d{4})\b""", RegexOption.IGNORE_CASE)
    private val MDY = Regex("""\b($MONTH_ALT)\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b""", RegexOption.IGNORE_CASE)

    private val AMOUNT_EU = Regex("""(?<![\d.,])((?:\d{1,3}(?:\.\d{3})+)|\d+),(\d{2})(?!\d)""")
    private val AMOUNT_US = Regex("""(?<![\d.,])((?:\d{1,3}(?:,\d{3})+)|\d+)\.(\d{2})(?!\d)(?!\.\d)""")

    private val WARR_A = Regex("""(garanzia|warranty|guarantee)\D{0,25}?(\d{1,2})\s*(mesi|months?|anni|anno|years?)""", RegexOption.IGNORE_CASE)
    private val WARR_B = Regex("""(\d{1,2})\s*(mesi|months?|anni|anno|years?)\D{0,25}?(garanzia|warranty|guarantee)""", RegexOption.IGNORE_CASE)

    private val DATE_POS = listOf(
        "scadenza", "scade", "entro il", "entro", "pagare entro", "pagamento entro", "termine",
        "data limite", "valido fino", "valida fino", "due date", "due by", "pay by", "payable by",
        "payment due", "expires", "expiry", "valid until", "valid through", "deadline"
    )
    private val RENEW_POS = listOf(
        "rinnovo", "rinnova", "prossimo addebito", "next billing", "next payment", "renews", "renewal"
    )
    private val PURCHASE_POS = listOf(
        "acquisto", "purchase", "data", "date", "ordine", "order", "emesso", "issued", "scontrino", "receipt"
    )
    private val DATE_NEG = listOf(
        "emissione", "emessa", "emesso", "fattura del", "data fattura", "data documento", "periodo",
        "lettura", "nato", "notifica", "dal ", "issued", "invoice date", "statement date", "period",
        "date of birth", "from "
    )
    private val AMT_STRONG = listOf(
        "da pagare", "importo dovuto", "totale dovuto", "netto a pagare", "importo totale",
        "totale fattura", "totale bolletta", "totale documento", "amount due", "total due",
        "balance due", "total amount", "amount to pay"
    )
    private val AMT_WEAK = listOf(
        "totale", "importo", "euro", "€", "$", "£", "sanzione", "pagare", "somma", "total", "amount", "pay", "sum"
    )
    private val AMT_NEG = listOf(
        "iva", "imponibile", "acconto", "credito", "arrotond", "spese di", "quota", "vat", "subtotal", "deposit"
    )

    private class Hit(val value: LocalDate, val pos: Int)
    private class Cand(val value: Double, val score: Int)

    // posizione di FINE dell'ultima parola trovata, cosi' "da pagare" batte "pagare"
    private fun lastIdx(win: String, ks: List<String>): Int =
        ks.maxOfOrNull { val i = win.lastIndexOf(it); if (i < 0) -1 else i + it.length } ?: -1

    private fun score(win: String, strong: List<String>, weak: List<String>, neg: List<String>): Int {
        val s = lastIdx(win, strong)
        val w = lastIdx(win, weak)
        val n = lastIdx(win, neg)
        return when {
            s >= 0 && s >= w && s >= n -> 10
            w >= 0 && w >= n -> 5
            n >= 0 -> -4
            else -> 0
        }
    }

    private fun window(t: String, pos: Int, len: Int): String =
        t.substring(maxOf(0, pos - len), pos).lowercase()

    private fun findDates(t: String, monthFirst: Boolean): List<Hit> {
        val out = mutableListOf<Hit>()
        for (m in NUM_DATE.findAll(t)) {
            try {
                var a = m.groupValues[1].toInt()
                var b = m.groupValues[2].toInt()
                var y = m.groupValues[3].toInt()
                if (y < 100) y += 2000
                // a/b = giorno/mese oppure mese/giorno (formato USA)
                if (a > 12) { /* giorno/mese */ }
                else if (b > 12) { val x = a; a = b; b = x }
                else if (monthFirst) { val x = a; a = b; b = x }
                out.add(Hit(LocalDate.of(y, b, a), m.range.first))
            } catch (e: Exception) {
                // data non valida: ignorata
            }
        }
        for (m in DMY.findAll(t)) {
            try {
                val mo = MONTHS[m.groupValues[2].lowercase()] ?: continue
                out.add(Hit(LocalDate.of(m.groupValues[3].toInt(), mo, m.groupValues[1].toInt()), m.range.first))
            } catch (e: Exception) {
                // data non valida: ignorata
            }
        }
        for (m in MDY.findAll(t)) {
            try {
                val mo = MONTHS[m.groupValues[1].lowercase()] ?: continue
                out.add(Hit(LocalDate.of(m.groupValues[3].toInt(), mo, m.groupValues[2].toInt()), m.range.first))
            } catch (e: Exception) {
                // data non valida: ignorata
            }
        }
        return out
    }

    private fun addAmounts(out: MutableList<Cand>, t: String, re: Regex, thousands: String) {
        for (m in re.findAll(t)) {
            val v = (m.groupValues[1].replace(thousands, "") + "." + m.groupValues[2]).toDoubleOrNull() ?: continue
            if (v < 0.5 || v > 1_000_000) continue
            out.add(Cand(v, score(window(t, m.range.first, 45), AMT_STRONG, AMT_WEAK, AMT_NEG)))
        }
    }

    fun parse(raw: String, c: Context, type: Int): Scan {
        val t = raw.replace('\n', ' ').replace(Regex("\\s+"), " ")
        val low = raw.lowercase()
        val today = LocalDate.now()
        val monthFirst = Locale.getDefault().country == "US"

        // scadenza o rinnovo
        val ds = findDates(t, monthFirst)
        val plausible = ds.filter { it.value.year in (today.year - 1)..(today.year + 5) }
        val posKeys = if (type == T_ABB) DATE_POS + RENEW_POS else DATE_POS
        val scored = plausible.map { it to score(window(t, it.pos, 50), posKeys, emptyList(), DATE_NEG) }
        val byKeyword = scored.filter { it.second > 0 }.maxByOrNull { it.second }?.first?.value
        val chosenDate = byKeyword
            ?: plausible.map { it.value }.filter { !it.isBefore(today) }.minOrNull()
            ?: plausible.map { it.value }.maxOrNull()

        // data di acquisto (garanzie): una data passata, meglio se vicina a parole come "acquisto" o "date"
        val past = ds.filter { !it.value.isAfter(today) && it.value.year >= today.year - 15 }
        val pastScored = past.map { it to score(window(t, it.pos, 40), PURCHASE_POS, emptyList(), emptyList()) }
        val purchase = pastScored.filter { it.second > 0 }.maxByOrNull { it.second }?.first?.value
            ?: past.map { it.value }.maxOrNull()

        // importo
        val amts = mutableListOf<Cand>()
        addAmounts(amts, t, AMOUNT_EU, ".")
        addAmounts(amts, t, AMOUNT_US, ",")
        val chosenAmount = amts.maxWithOrNull(compareBy<Cand>({ it.score }, { it.value }))?.value

        // durata della garanzia
        var warranty: Int? = null
        val wa = WARR_A.find(t)
        val wb = WARR_B.find(t)
        if (wa != null) {
            val n = wa.groupValues[2].toInt()
            warranty = if (wa.groupValues[3].lowercase().startsWith("m")) n else n * 12
        } else if (wb != null) {
            val n = wb.groupValues[1].toInt()
            warranty = if (wb.groupValues[2].lowercase().startsWith("m")) n else n * 12
        }

        // ogni quanto si ripete (abbonamenti)
        val repeat: Int? = when {
            low.contains(Regex("bimestrale|bimonthly")) -> 2
            low.contains(Regex("trimestrale|quarterly")) -> 3
            low.contains(Regex("semestrale|half-yearly|biannual")) -> 6
            low.contains(Regex("mensile|monthly|al mese|per month|/ ?month|every month")) -> 1
            low.contains(Regex("annuale|annual|yearly|all'anno|per year|/ ?year|every year")) -> 12
            else -> null
        }

        // nome del negozio: la prima riga che sembra un nome
        val store = raw.lines().map { it.trim() }.firstOrNull { line ->
            line.length in 3..40 && line.count { ch -> ch.isLetter() } >= 3 && line.count { ch -> ch.isDigit() } <= 3
        }

        // tipo di documento
        fun has(vararg k: String) = k.any { low.contains(it) }
        val kind: Pair<String, Int> = when {
            has("verbale", "violazione", "codice della strada", "contravvenzione", "traffic violation", "parking ticket", "citation") ->
                c.getString(R.string.kind_fine) to 6
            has("kwh", "energia elettrica", "electricity") -> c.getString(R.string.kind_bill_power) to 6
            has("smc", "gas naturale", "natural gas") -> c.getString(R.string.kind_bill_gas) to 6
            has("servizio idrico", "acquedotto", "water bill", "water supply") -> c.getString(R.string.kind_bill_water) to 6
            has("bolletta", "utility bill") -> c.getString(R.string.kind_bill) to 6
            has("tassa automobilistica", "bollo auto", "vehicle tax", "road tax", "car tax") -> scadName(c, 0) to 0
            has("revisione", "vehicle inspection") || low.contains(Regex("\\bmot\\b")) -> scadName(c, 1) to 1
            has("polizza", "assicurazione", "insurance") -> scadName(c, 2) to 2
            has("tagliando", "car service") -> scadName(c, 3) to 3
            has("caldaia", "bollino blu", "boiler") -> scadName(c, 4) to 4
            low.contains(Regex("\\b(imu|tari|tasi)\\b")) || has("property tax", "council tax") -> scadName(c, 5) to 5
            has("fattura", "invoice") -> c.getString(R.string.kind_invoice) to 6
            else -> c.getString(R.string.kind_document) to 6
        }

        return Scan(
            date = chosenDate,
            amount = chosenAmount,
            name = kind.first,
            category = kind.second,
            otherDates = plausible.map { it.value }.distinct().filter { it != chosenDate }.sorted().take(4),
            otherAmounts = amts.map { it.value }.distinct().filter { it != chosenAmount }.sortedDescending().take(4),
            purchaseDate = purchase,
            warrantyMonths = warranty,
            repeatMonths = repeat,
            storeGuess = store
        )
    }
}
