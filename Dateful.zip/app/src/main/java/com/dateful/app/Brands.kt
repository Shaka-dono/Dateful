package com.dateful.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.text.Normalizer

class Badge(val glyph: String, val color: Int, val size: Float, val fg: Int = Color.WHITE)

/** Riconosce il nome di un servizio e restituisce un badge con il suo colore. Tutto offline. */
object Brands {

    private class Entry(val keys: List<String>, val badge: Badge)

    private val DARK = 0xFF1A1A1A.toInt()

    private fun e(keys: String, glyph: String, color: Long, size: Float = 18f, fg: Int = Color.WHITE) =
        Entry(keys.split(","), Badge(glyph, color.toInt(), size, fg))

    // L'ordine conta: i nomi piu' specifici vanno prima di quelli generici.
    private val CATALOG = listOf(
        // video e streaming
        e("netflix", "N", 0xFFE50914),
        e("disney", "D+", 0xFF113CCF, 15f),
        e("primevideo,amazonprime,prime,amazon", "P", 0xFF00A8E1),
        e("dazn", "DAZN", 0xFF111111, 11f),
        e("paramount", "P+", 0xFF0064FF, 15f),
        e("discovery", "d+", 0xFF2175D9, 15f),
        e("raiplay", "Rai", 0xFF0033A0, 13f),
        e("sky", "sky", 0xFF0072C9, 14f),
        e("now", "NOW", 0xFF222222, 12f),
        e("appletv", "tv", 0xFF1C1C1E, 16f),
        e("applemusic", "♪", 0xFFFA243C, 22f),
        e("icloud", "☁", 0xFF3693F3, 22f),
        e("apple", "A", 0xFF1C1C1E),
        e("youtubemusic", "♪", 0xFFFF0000, 22f),
        e("youtube", "▶", 0xFFFF0000, 16f),
        // musica e libri
        e("spotify", "S", 0xFF1DB954),
        e("audible", "A", 0xFFF8991C),
        e("kindle", "K", 0xFFFF9900),
        // giochi
        e("xbox,gamepass", "X", 0xFF107C10),
        e("playstation,psplus", "PS", 0xFF003791, 15f),
        e("nintendo", "N", 0xFFE60012),
        e("steam", "S", 0xFF1B2838),
        // software e cloud
        e("chatgpt,openai", "G", 0xFF10A37F),
        e("claude,anthropic", "C", 0xFFD97757),
        e("microsoft,office365,onedrive", "M", 0xFF0078D4),
        e("google", "G", 0xFF4285F4),
        e("dropbox", "D", 0xFF0061FF),
        e("adobe,photoshop,creativecloud", "A", 0xFFFA0F00),
        e("notion", "N", 0xFF2B2B2B),
        e("canva", "C", 0xFF00C4CC),
        e("duolingo", "D", 0xFF58CC02),
        e("telegram", "T", 0xFF27A7E7),
        e("linkedin", "in", 0xFF0A66C2, 16f),
        // telefono e internet
        e("vodafone", "V", 0xFFE60000),
        e("tim", "TIM", 0xFF003C8F, 12f),
        e("windtre,wind", "W3", 0xFFFF6900, 15f),
        e("iliad", "iliad", 0xFFCC0000, 12f),
        e("fastweb", "F", 0xFFFFC400, 18f, DARK),
        e("poste,postepay,postemobile", "P", 0xFFFFDD00, 18f, DARK),
        // categorie generiche
        e("palestra,fitness,gym,crossfit,piscina,yoga,pilates", "🏋️", 0xFFEA580C, 20f),
        e("telefono,mobile,sim,ricaricabile,cellulare", "📱", 0xFF2563EB, 20f),
        e("internet,fibra,wifi,adsl,router", "🌐", 0xFF0891B2, 20f),
        e("assicur,polizza", "🛡️", 0xFF16A34A, 20f),
        e("cloud,storage,backup", "☁️", 0xFF3B82F6, 20f),
        e("musica,music,radio", "🎵", 0xFFDB2777, 20f),
        e("film,serie,streaming,video,cinema,tv", "🎬", 0xFF7C3AED, 20f),
        e("giochi,gaming,game", "🎮", 0xFF4F46E5, 20f),
        e("libri,audiolibri,ebook", "📚", 0xFFB45309, 20f),
        e("giornale,quotidiano,rivista,news", "📰", 0xFF475569, 20f),
        e("luce,energia,elettric", "💡", 0xFFCA8A04, 20f),
        e("gas", "🔥", 0xFFDC2626, 20f),
        e("acqua", "💧", 0xFF0284C7, 20f),
        e("affitto,mutuo,condominio", "🏠", 0xFF0D9488, 20f),
        e("vpn,antivirus,password", "🔒", 0xFF334155, 20f)
    )

    private val PALETTE = listOf(
        0xFF0EA5E9, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316,
        0xFF14B8A6, 0xFF6366F1, 0xFF84CC16, 0xFFEF4444
    ).map { it.toInt() }

    val suggestions = listOf(
        "Netflix", "Disney+", "Prime Video", "Amazon Prime", "DAZN", "Sky", "NOW",
        "Paramount+", "Apple TV+", "Apple Music", "iCloud+", "YouTube Premium", "Spotify",
        "Audible", "Kindle Unlimited", "Discovery+", "Xbox Game Pass", "PlayStation Plus",
        "Nintendo Switch Online", "ChatGPT Plus", "Claude Pro", "Microsoft 365", "Google One",
        "Dropbox", "Adobe Creative Cloud", "Notion", "Canva", "Duolingo", "Telegram Premium",
        "Vodafone", "TIM", "WindTre", "Iliad", "Fastweb", "Palestra", "Telefono",
        "Internet casa", "Assicurazione"
    )

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    fun badgeFor(name: String): Badge {
        val n = norm(name).trim()
        if (n.isEmpty()) return Badge("🔁", 0xFF64748B.toInt(), 20f)
        val words = n.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        val joined = words.joinToString("")
        for (en in CATALOG) {
            for (k in en.keys) {
                // parole corte (tim, sky, now, gas...) solo se sono una parola intera
                val hit = if (k.length >= 5) joined.contains(k) else words.contains(k)
                if (hit) return en.badge
            }
        }
        val letter = words.firstOrNull()?.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        return Badge(letter, PALETTE[(n.hashCode() and 0x7fffffff) % PALETTE.size], 18f)
    }

    fun applyBadge(tv: TextView, name: String) {
        val b = badgeFor(name)
        val d = tv.resources.displayMetrics.density
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(b.color)
        tv.background = bg
        tv.text = b.glyph
        tv.setTextColor(b.fg)
        tv.textSize = b.size
        tv.gravity = Gravity.CENTER
        tv.setTypeface(null, Typeface.BOLD)
        val px = (40 * d).toInt()
        val lp = (tv.layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(px, px)
        lp.width = px
        lp.height = px
        lp.setMargins(0, 0, (12 * d).toInt(), 0)
        tv.layoutParams = lp
    }

    /** Icona dell'app installata se c'e' (e se attivata nelle impostazioni), altrimenti il badge colorato. */
    fun show(tv: TextView, name: String) {
        val c = tv.context
        if (Prefs.icons(c)) {
            val d = AppIcons.find(c, name)
            if (d != null) {
                val dens = tv.resources.displayMetrics.density
                val px = (40 * dens).toInt()
                tv.background = d
                tv.text = ""
                val lp = (tv.layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(px, px)
                lp.width = px
                lp.height = px
                lp.setMargins(0, 0, (12 * dens).toInt(), 0)
                tv.layoutParams = lp
                return
            }
        }
        applyBadge(tv, name)
    }

    fun resetEmoji(tv: TextView, color: Int) {
        val d = tv.resources.displayMetrics.density
        tv.background = null
        tv.setTextColor(color)
        tv.textSize = 28f
        tv.gravity = Gravity.START or Gravity.TOP
        tv.setTypeface(null, Typeface.NORMAL)
        val lp = tv.layoutParams as? LinearLayout.LayoutParams
        if (lp != null) {
            lp.width = (44 * d).toInt()
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.setMargins(0, 0, 0, 0)
            tv.layoutParams = lp
        }
    }
}

/** Elenco delle app installate (solo quelle con icona nel menu) e ricerca per nome. */
object AppIcons {
    class AppInfo(val label: String, val pkg: String)

    private var cached: List<AppInfo>? = null
    private val matches = HashMap<String, String?>()

    fun reset() {
        cached = null
        matches.clear()
    }

    fun apps(c: Context): List<AppInfo> {
        cached?.let { return it }
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try {
            pm.queryIntentActivities(i, 0)
                .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .filter { it.pkg != c.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        } catch (e: Exception) {
            emptyList()
        }
        cached = list
        return list
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]"), "")

    private fun pkgFor(c: Context, name: String): String? {
        val n = norm(name)
        if (n.length < 3) return null
        if (matches.containsKey(n)) return matches[n]
        var best: AppInfo? = null
        var bestDiff = Int.MAX_VALUE
        for (a in apps(c)) {
            val l = norm(a.label)
            if (l.isEmpty()) continue
            if (l == n) {
                best = a
                break
            }
            if (minOf(l.length, n.length) >= 4 && (l.contains(n) || n.contains(l))) {
                val diff = Math.abs(l.length - n.length)
                if (diff < bestDiff) {
                    best = a
                    bestDiff = diff
                }
            }
        }
        matches[n] = best?.pkg
        return best?.pkg
    }

    fun find(c: Context, name: String): Drawable? {
        val pkg = pkgFor(c, name) ?: return null
        return try {
            c.packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
    }
}
